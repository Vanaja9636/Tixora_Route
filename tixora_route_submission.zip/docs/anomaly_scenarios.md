# Isolated anomaly scenarios

`tixora_route.anomalies.build_anomaly_fixture(scenario)` creates a new in-memory SQLite database, generates a small clean baseline, then injects exactly one labeled case. It returns `(engine, session)`; call `close_anomaly_fixture(engine, session)` when finished. These fixtures never touch `data/tixora_route.db` and are never called by normal generation or routing.

| Fixture label | Injected data | Detector rule |
|---|---|---|
| `agent_beyond_capacity` | Two active ticket assignments to an agent with capacity 1 | Current load, based on each ticket's latest assignment, exceeds the agent capacity |
| `incorrect_channel_sla_calendar` | Change the channel calendar after the SLA creation event recorded the original calendar | Recorded calendar differs from current channel policy |
| `lost_reopening_history` | Set ticket status to `reopened` without a reopening SLA event | Reopened ticket has no retained `reopened` event |
| `transfer_loop` | Three transfer events oscillating between two agents | At least three transfer events involve no more than two agents |
| `priority_contradicts_safety_rule` | Set safety intent with non-urgent priority | PR-001 safety priority floor is violated |

Detector implementation is in `src/tixora_route/validation.py`. Labels are computed from business records and are not passed into the routing engine.
