# Tixora Route data dictionary

SQLite stores timestamps as naive UTC `DATETIME` values. Required fields are `NOT NULL`; a question mark denotes an optional field. Integer `id` columns are generated primary keys unless a public-ID format is stated. Text values are UTF-8. See `src/tixora_route/models.py` for executable SQLAlchemy declarations and `src/tixora_route/enums.py` for shared values.

## Entities

| Entity/table | Cardinality and fields |
|---|---|
| **Customer** (`customers`) | One customer has 0..N tickets and 0..N permitted channels. `id` INTEGER PK; `name` VARCHAR(120) required; `email` VARCHAR(180) required, unique and indexed; `language_code` VARCHAR(8) required FK to `languages.code` (generated default `en`). |
| **Channel** (`channels`) | A channel has 0..N tickets and 0..N customers. `id` INTEGER PK; `name` VARCHAR(40) required and unique; `calendar_type` VARCHAR(24) required, one of `business`, `calendar`, `24x7`. |
| **Ticket** (`tickets`) | Each ticket references exactly one customer, channel, intent, and language; a ticket has 0..N messages, assignment events, SLA events, and resolution records. `id` INTEGER PK; `public_id` VARCHAR(30) required/unique/indexed, format `TKT-2026-NNNNNN`; `customer_id`, `channel_id`, `intent_id`, `language_id` INTEGER required FKs; `subject` VARCHAR(240) required; `priority` VARCHAR(16) required, `low|normal|high|urgent`; `status` VARCHAR(20) required, `new|open|pending|escalated|resolved|reopened|closed`; `required_skill` VARCHAR(60) required; `created_at`, `due_at` DATETIME required; `resolved_at` DATETIME optional; `customer_satisfaction` FLOAT optional (1–5). Indexed by status/priority and creation time. |
| **Message** (`messages`) | Each message belongs to exactly one ticket and may reply to one earlier message; a parent message can have 0..N replies. `id` INTEGER PK; `public_id` VARCHAR(64) required/unique/indexed, format `MSG-{ticket_public_id}-NNN`; `ticket_id` INTEGER required FK with delete cascade; `parent_message_id` INTEGER optional self-FK (delete sets null); `sender_type` VARCHAR(20) required, `customer|agent|system`; `body` TEXT required; `created_at` DATETIME required. Indexed by ticket and creation time. |
| **Intent** (`intents`) | An intent has 0..N tickets. `id` INTEGER PK; `name` VARCHAR(60) required/unique; `required_skill` VARCHAR(60) required. Business taxonomy: `billing`, `technical`, `account_access`, `safety`, `returns`. The `general` intent is an internal fallback used by the general queue and is excluded from randomized business-ticket generation. |
| **Language** (`languages`) | A language has 0..N tickets. `id` INTEGER PK; `code` VARCHAR(8) required/unique; `name` VARCHAR(40) required. Seed values: `en`, `es`, `hi`, `te`. |
| **PriorityRule** (`priority_rules`) | Policy record keyed by an intent name; rules can have non-overlapping effective intervals. `id` INTEGER PK; `name` VARCHAR(80) required/unique; `intent_name` VARCHAR(60) required FK to `intents.name`/indexed; `min_priority` VARCHAR(16) required, `low|normal|high|urgent`; `safety_rule` BOOLEAN required; `effective_from` DATETIME required; `effective_to` DATETIME optional and later than `effective_from`. The safety rule PR-001 requires `urgent`. |
| **Agent** (`agents`) | An agent has 0..N skills and 0..N target/source assignment events. `id` INTEGER PK; `public_id` VARCHAR(20) required/unique/indexed, format `AGT-NNNNNN`; `name` VARCHAR(100) required; `language_code` VARCHAR(8) required FK to `languages.code`; `shift_start`, `shift_end` INTEGER required hours in 0..24, with end > start; `capacity` INTEGER required (business-valid minimum 1); `active` BOOLEAN required. Database permits capacity 0 to represent invalid/anomaly fixtures; strict validation rejects it. |
| **Skill** (`skills`) | A skill can belong to 0..N agents and 0..N queues. `id` INTEGER PK; `name` VARCHAR(60) required/unique. Skills cover the five business intents and the internal `general` fallback. |
| **Queue** (`queues`) | A queue has 0..N skills and groups work by intent. `id` INTEGER PK; `name` VARCHAR(60) required/unique; `intent_name` VARCHAR(60) required FK to `intents.name`/indexed. Seed queue names use `{intent}_queue`, plus `general`, which handles safe fallback when no eligible business-intent agent is available. |
| **AssignmentEvent** (`assignment_events`) | Each event belongs to one ticket. Target agent is optional for queued decisions; source agent is optional and used for transfers. `id` INTEGER PK; `public_id` VARCHAR(64) required/unique, first assignment format `ASN-{ticket_public_id}-NNN`; `ticket_id` INTEGER required FK; `agent_id` INTEGER optional FK; `source_agent_id` INTEGER optional FK; `queue_name` VARCHAR(60) required; `event_type` VARCHAR(24) required, `assigned|transferred|escalated|queued|reopened`; `routing_score` FLOAT required; `reason` TEXT required; `decision_metadata` TEXT required JSON; `created_at` DATETIME required. Indexed by ticket/agent and event time. |
| **SLAEvent** (`sla_events`) | Each event belongs to one ticket. `id` INTEGER PK; `public_id` VARCHAR(64) required/unique; the initial deadline event format is exactly `SLA-{ticket_public_id}`; subsequent lifecycle records use descriptive suffixes; `ticket_id` INTEGER required FK; `event_type` VARCHAR(24) required, `created|breached|resolved|reopened|escalated|closed`; `due_at`, `created_at` DATETIME required; `elapsed_business_minutes` FLOAT optional; `details` TEXT required. Indexed by ticket/type and event time. |
| **Resolution** (`resolutions`) | A ticket has 0..N resolution records so reopening and resolving again never overwrites prior outcomes. `id` INTEGER PK; `ticket_id` INTEGER required FK; `summary` TEXT required; `resolution_code` VARCHAR(40) required; `resolved_at` DATETIME required; `customer_satisfaction` FLOAT optional (1–5). Indexed by ticket/resolution time. |

## Many-to-many bridge tables

| Table | Cardinality | Fields and constraints |
|---|---|---|
| `customer_channels` | Customers 0..N ↔ channels 0..N | `customer_id` and `channel_id` are required cascading FKs and a composite primary key. Duplicate customer/channel pairs are impossible. |
| `agent_skills` | Agents 0..N ↔ skills 0..N | `agent_id` and `skill_id` are required cascading FKs and a composite primary key. |
| `queue_skills` | Queues 0..N ↔ skills 0..N | `queue_id` and `skill_id` are required cascading FKs and a composite primary key. |

## Validation and relationship rules

- Every declared FK must resolve; tickets require customer/channel/intent/language, messages require a ticket, and events/resolutions require a ticket.
- Public identifiers and email addresses are unique. Public IDs are generated from stable numeric sequences, zero-padded, and treated as immutable by application services.
- Ticket due time must be after creation; messages, SLA events, and resolutions cannot predate ticket creation; resolution intervals and priority-rule effective intervals must be ordered.
- Ticket priority/status, channel calendar, message sender, and event type values must belong to their enumerations.
- Safety-intent tickets must be urgent. A normal assignment must satisfy skill, language, shift, active-agent, and current-capacity rules.
- Exactly one SLA `created` event must reconcile with the ticket due time and channel calendar. Each reopened status must have a retained `reopened` event.
- Every generated ticket has at least one customer message. Thread parent references must stay within the same ticket.
- `validate()` checks ticket status-group totals against total ticket count and reports all violations without consulting ground-truth labels.
