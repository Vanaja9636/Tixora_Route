# Tixora Route business rules and challenge traceability

## Business rules

| ID | Rule |
|---|---|
| PR-001 | A ticket with `safety` intent has `urgent` priority, regardless of the incoming priority. |
| SLA-001 | Targets are urgent=30, high=120, normal=240, low=480 business minutes. Calendar is selected by the ticket's source channel. |
| SLA-002 | Business time is Monday–Friday, 09:00–17:00 UTC. `calendar` and `24x7` use wall-clock time. Timestamps are naive UTC. |
| RT-001 | Routing selects the intent queue and requires an active agent with the ticket's required skill and exact language match. |
| RT-002 | Routing time must fall inside `[shift_start, shift_end)` and current active load must be less than capacity. |
| RT-003 | Eligible score = priority rank × 100 + channel bonus − active load × 10; channel bonuses: phone=15, chat=10, email=5, other=0. Ties use lower load, then `AGT-...` ascending. |
| RT-004 | If no candidate meets all hard constraints, the ticket is queued as `pending`; a queued assignment event retains reason and rejected-candidate metadata. |
| LIFE-001 | State changes and assignment transfers append events. Reopen does not delete resolutions/events; a later resolution adds another resolution record. |
| LIFE-002 | Escalation warning is reached at 80% of target business time by default; `escalate_if_due` can be called with another threshold. |
| DATA-001 | Seed `20261022` and stable sequences generate deterministic rows; no truth label is an input to generation or routing. |
| DATA-002 | Synthetic names, `.test` emails, ticket text, and messages are invented locally; no real user data or third-party source is used. |

## Requirement-to-implementation map

| Challenge requirement | Implementation | Representative tests |
|---|---|---|
| 1. Thirteen entities, FKs, relationships, bridge tables, indexes and constraints | `src/tixora_route/models.py`, `docs/data_dictionary.md` | `tests/test_models.py` |
| 2. Seeded synthetic generation, master-first ordering, configurable scale and batches | `src/tixora_route/generator.py`, `src/tixora_route/taxonomy.py` | `tests/test_generator.py` |
| 3. Immutable, zero-padded public ID formats | `generator.py`, `routing.py`, `sla.py`, `models.py` | `tests/test_generator.py`, `tests/test_routing.py`, `tests/test_sla.py` |
| 4. Explainable routing, candidate rejection, channel scoring, shifts and capacity | `src/tixora_route/routing.py`, `simulation.py` | `tests/test_routing.py`, `tests/test_business_rules.py` |
| 5. Business calendars, elapsed business time, escalation and append-only lifecycle | `calendar.py`, `sla.py`, `lifecycle.py`, `models.py` | `tests/test_sla.py`, `tests/test_lifecycle.py` |
| 6. Five isolated anomaly cases and detectors | `src/tixora_route/anomalies.py`, `validation.detect_anomalies` | `tests/test_anomalies.py`, `tests/test_anomaly_fixtures.py` |
| 7. Business-rule ground truth, exported after routing and never used by router | `src/tixora_route/exports.py`, `routing.py` | `tests/test_exports_metrics.py` |
| 8. Referential, enum, date, lifecycle, route, SLA, history and count validation | `src/tixora_route/validation.py` | `tests/test_validation.py`, `tests/test_anomalies.py` |
| 9. CSV/JSON/SQL, metrics, SHA-256, row counts and reproducibility | `src/tixora_route/exports.py`, `cli.py` (`repro`) | `tests/test_exports_metrics.py` |
| 10. Required FastAPI routes, Pydantic response models, pagination and Swagger | `src/tixora_route/api.py`, `schemas.py` | `tests/test_api.py` |
| 11. Init/generate/simulate/validate/export/metrics/all/demo CLI | `src/tixora_route/cli.py` | Run commands in `README.md`; API and service tests |
| 12. Model, generator, routing, SLA, lifecycle, anomaly, metrics, exports and API tests | `tests/` | `python -m pytest -q tests` |
| 13. Requested project structure and Windows scripts | project root, `scripts/`, `src/tixora_route/` | package import and CLI execution |
| 14. Setup, architecture, field dictionary, rule mapping and troubleshooting docs | `README.md`, `RUN_ME_FIRST.md`, `docs/` | manual review; commands verified at runtime |

## Anomaly labels

The detector names are stable CSV/JSON labels:

- `agent_beyond_capacity`
- `incorrect_channel_sla_calendar`
- `lost_reopening_history`
- `transfer_loop`
- `priority_contradicts_safety_rule`

`build_anomaly_fixture(scenario)` creates a separate in-memory database for exactly one anomaly. Normal demo generation stays clean. Labels are derived from observable ticket/agent/SLA/assignment fields using these rules; `routing.py` does not import `exports.py` or `ground_truth`.
