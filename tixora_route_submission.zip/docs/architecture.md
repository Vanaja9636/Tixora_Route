# Tixora Route architecture

## Runtime components

```text
CLI / FastAPI
    ├── configuration + SQLAlchemy session factory
    ├── generator ──> master data ──> tickets/messages/SLA events
    ├── routing + simulation ──> assignment/queue audit events
    ├── SLA calendar + lifecycle ──> append-only SLA/resolution history
    ├── validation + anomaly detectors ──> structured findings
    └── metrics + exports ──> CSV, JSON, SQL seed, SHA-256 manifest
                         SQLite
```

`src/tixora_route/models.py` maps 13 domain entities and the `customer_channels`, `agent_skills`, and `queue_skills` composite-key bridge tables. Foreign keys, uniqueness, indexes, enum/check constraints, lifecycle timestamps, and optional relationships are expressed in SQLAlchemy metadata. `database.init_db()` creates the schema and upgrades supported older SQLite columns without discarding existing records.

## Data flow

1. `generator.seed_reference_data` inserts taxonomy, rules, queues, customers, and agents before ticket/event data.
2. `generator.generate` uses `random.Random(seed)`, a fixed 2026-01-01 UTC baseline, stable public-ID sequences, bounded DB batches, and threaded additional messages.
3. `sla.calculate_due` resolves SLA minutes from priority and applies the ticket channel's UTC business calendar.
4. `simulation.simulate` preloads agents/skills/queues and current load, then routes only `new` tickets.
5. `routing.route_ticket` filters hard constraints (active, skill, language, shift, capacity), ranks eligible agents by priority/channel score, load, then stable ID, and persists both assigned and queued decisions with rejected-candidate metadata.
6. `lifecycle` appends transfer, escalation, resolution, reopen, and close events; each resolution cycle is retained.
7. `validation` audits source records. `detect_anomalies` uses operational data only; it never reads the exported ground truth.
8. `exports.export_all` streams each SQL table to CSV/JSON, derives expected decisions/labels after routing, exports SQL inserts, and hashes outputs.

## Cardinality and key policy

- One customer, channel, intent, or language may relate to many tickets; each ticket has exactly one of each.
- A ticket has many messages, assignment events, SLA events, and resolution records.
- Customers/channels, agents/skills, and queues/skills are many-to-many with composite primary keys.
- Public identifiers are separate from internal integer primary/foreign keys. Exported child tables include public reference columns alongside internal FKs.
- Event history is append-only. Current assignment/capacity is calculated from each active ticket's latest assignment event, not by counting historical transfers.

## Operational assumptions

- All synthetic `datetime` values are naive UTC. No DST conversion is applied.
- `business` means Mon–Fri 09:00–17:00 UTC; `calendar` and `24x7` mean continuous wall-clock minutes.
- The default channel calendars are in `taxonomy.CHANNELS`; the channel value is also copied to SLA creation event details for drift detection.
- The generator uses fictional `.test` email addresses and synthetic text. No customer data is imported.
