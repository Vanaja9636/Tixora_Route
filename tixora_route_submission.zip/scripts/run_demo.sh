#!/usr/bin/env sh
set -eu
PYTHONPATH=src python -m tixora_route.cli all --tickets 100 --agents 100 --messages 300
pytest -q
