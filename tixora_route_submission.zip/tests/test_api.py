"""
Tests for the FastAPI REST API.

Verifies:
- GET /health → 200 ok
- GET /tickets → paginated list
- GET /tickets/{id} → single ticket
- GET /tickets/{id}/messages → threaded messages
- GET /tickets/{id}/history → combined history
- GET /agents → paginated list
- GET /queues → list
- POST /tickets/{id}/route → routing decision
- GET /metrics → platform metrics
- POST /validate → validation result
- 404 on unknown ticket
- Correct HTTP status codes
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from tixora_route.api import app, get_session
from tixora_route.generator import generate
from tixora_route.models import Agent, Language, Ticket


@pytest.fixture
def client(db):
    generate(db, tickets=5, messages=10, seed=20261022, agent_count=12)

    def override_session():
        return db

    app.dependency_overrides[get_session] = override_session
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def test_health(client):
    """GET /health must return 200 with status=ok."""
    r = client.get("/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert data["service"] == "tixora-route"


def test_docs_available(client):
    """Swagger /docs must return 200."""
    r = client.get("/docs")
    assert r.status_code == 200


def test_list_tickets(client):
    """GET /tickets must return a list with pagination fields."""
    r = client.get("/tickets")
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data
    assert "skip" in data
    assert "limit" in data


def test_ticket_pagination(client):
    """GET /tickets?skip=0&limit=10 must respect pagination."""
    r = client.get("/tickets?skip=0&limit=10")
    assert r.status_code == 200
    data = r.json()
    assert len(data["items"]) <= 10
    assert data["total"] == 5


def test_ticket_detail_messages_and_history(client):
    ticket_id = "TKT-2026-000001"
    assert client.get(f"/tickets/{ticket_id}").status_code == 200
    messages = client.get(f"/tickets/{ticket_id}/messages")
    history = client.get(f"/tickets/{ticket_id}/history")
    assert messages.status_code == 200
    assert len(messages.json()) >= 1
    assert history.status_code == 200
    assert any(event["event_type"] == "created" for event in history.json())


def test_ticket_not_found(client):
    """GET /tickets/{unknown} must return 404."""
    r = client.get("/tickets/TKT-9999-999999")
    assert r.status_code == 404


def test_ticket_messages_not_found(client):
    """GET /tickets/{unknown}/messages must return 404."""
    r = client.get("/tickets/TKT-9999-999999/messages")
    assert r.status_code == 404


def test_ticket_history_not_found(client):
    """GET /tickets/{unknown}/history must return 404."""
    r = client.get("/tickets/TKT-9999-999999/history")
    assert r.status_code == 404


def test_route_not_found(client):
    """POST /tickets/{unknown}/route must return 404."""
    r = client.post("/tickets/TKT-9999-999999/route")
    assert r.status_code == 404


def test_list_agents(client):
    """GET /agents must return paginated agent list."""
    r = client.get("/agents")
    assert r.status_code == 200
    data = r.json()
    assert "items" in data
    assert "total" in data
    assert data["total"] == 12


def test_list_queues(client):
    """GET /queues must return a list."""
    r = client.get("/queues")
    assert r.status_code == 200
    assert isinstance(r.json(), list)


def test_metrics_endpoint(client):
    """GET /metrics must return platform metrics dict."""
    r = client.get("/metrics")
    assert r.status_code == 200
    data = r.json()
    assert "tickets_total" in data


def test_validate_endpoint(client):
    """POST /validate must return validation result."""
    r = client.post("/validate")
    assert r.status_code == 200
    data = r.json()
    assert "valid" in data
    assert "issue_count" in data
    assert "issues" in data
    assert "counts" in data
    assert data["valid"] is True


def test_route_ticket_and_conflict_status(client, db):
    ticket = db.scalar(select(Ticket).where(Ticket.public_id == "TKT-2026-000001"))
    agent = next(
        candidate
        for candidate in db.scalars(select(Agent))
        if candidate.active
        and ticket.required_skill in {skill.name for skill in candidate.skills}
    )
    ticket.language_id = db.scalar(
        select(Language.id).where(Language.code == agent.language_code)
    )
    ticket.created_at = ticket.created_at.replace(hour=10)
    db.flush()

    first = client.post(f"/tickets/{ticket.public_id}/route")
    assert first.status_code == 200
    if first.json()["decision"] == "assigned":
        second = client.post(f"/tickets/{ticket.public_id}/route")
        assert second.status_code == 409
