"""
Tests for the five anomaly detectors.

Each anomaly is created in an isolated fixture.
The clean baseline (via validation) must NOT trigger any anomaly.
Each injected anomaly must trigger its corresponding detector.

Five anomalies:
  1. agent_beyond_capacity
  2. incorrect_channel_sla_calendar
  3. lost_reopening_history
  4. transfer_loop
  5. priority_contradicts_safety_rule
"""
import pytest
from sqlalchemy import select
from tixora_route.generator import generate
from tixora_route.models import Ticket, SLAEvent, AssignmentEvent, Agent
from tixora_route.validation import detect_anomalies, validate


def test_clean_baseline_no_anomalies(db):
    """Clean baseline must produce zero anomalies."""
    generate(db, tickets=20, messages=20, seed=20261022, agent_count=20)
    anomalies = detect_anomalies(db)
    # Only check the five standard anomaly types
    standard = {
        "agent_beyond_capacity", "incorrect_channel_sla_calendar",
        "lost_reopening_history", "transfer_loop", "priority_contradicts_safety_rule",
    }
    found_standard = [a for a in anomalies if a["scenario"] in standard]
    assert len(found_standard) == 0, f"Unexpected anomalies in clean baseline: {found_standard}"


def test_all_five_anomaly_detectors(db):
    """All five anomaly detectors must fire when anomalies are injected."""
    generate(db, tickets=8, messages=8, seed=20261022, agent_count=12)
    tickets = list(db.scalars(select(Ticket).order_by(Ticket.id)))
    agents = list(db.scalars(select(Agent).limit(2)))

    # ── Anomaly 5: Priority contradicts safety rule ───────────────────────────
    safety_ticket = tickets[0]
    from tixora_route.models import Intent
    safety_intent = next(
        i for i in db.scalars(select(Intent)) if i.name == "safety"
    )
    safety_ticket.intent = safety_intent
    safety_ticket.required_skill = "safety"
    safety_ticket.priority = "normal"  # Violates PR-001

    # ── Anomaly 2: Wrong channel calendar in SLA ──────────────────────────────
    cal_ticket = tickets[1]
    sla_created = next(e for e in cal_ticket.sla_events if e.event_type == "created")
    # Change channel calendar to differ from what was recorded
    original_cal = cal_ticket.channel.calendar_type
    cal_ticket.channel.calendar_type = "24x7" if original_cal == "business" else "business"

    # ── Anomaly 3: Reopened ticket loses history ──────────────────────────────
    lost_ticket = tickets[3]
    lost_ticket.status = "reopened"
    for ev in list(lost_ticket.sla_events):
        if ev.event_type == "reopened":
            db.delete(ev)

    # ── Anomaly 4: Transfer loop (A → B → A with 3+ transfers) ───────────────
    loop_ticket = tickets[2]
    if len(agents) >= 2:
        for i, agent in enumerate([agents[0], agents[1], agents[0]], 1):
            db.add(AssignmentEvent(
                public_id=f"ASN-{loop_ticket.public_id}-L{i:02}",
                ticket_id=loop_ticket.id,
                agent_id=agent.id,
                queue_name="general",
                event_type="transferred",
                reason="loop_fixture",
                created_at=loop_ticket.created_at,
            ))

    # ── Anomaly 1: Agent beyond capacity ─────────────────────────────────────
    if agents:
        cap_agent = agents[0]
        cap_agent.capacity = 1  # Set cap to 1
        for i, t in enumerate(tickets[:3], 1):
            t.status = "open"
            db.add(AssignmentEvent(
                public_id=f"ASN-{t.public_id}-C{i:02}",
                ticket_id=t.id,
                agent_id=cap_agent.id,
                queue_name="general",
                event_type="assigned",
                reason="capacity_fixture",
                created_at=t.created_at,
            ))

    db.flush()

    found = detect_anomalies(db)
    scenarios = {x["scenario"] for x in found}

    expected = {
        "agent_beyond_capacity",
        "incorrect_channel_sla_calendar",
        "lost_reopening_history",
        "transfer_loop",
        "priority_contradicts_safety_rule",
    }
    assert expected.issubset(scenarios), f"Missing anomalies: {expected - scenarios}"


def test_anomaly_1_agent_beyond_capacity(db):
    """Detector 1: agent_beyond_capacity fires when load > capacity."""
    generate(db, tickets=4, messages=4, seed=20261022, agent_count=4)
    tickets = list(db.scalars(select(Ticket).order_by(Ticket.id)))
    agent = db.scalar(select(Agent))
    agent.capacity = 1  # Cap is 1, assign 3 active tickets
    for i, t in enumerate(tickets[:3], 1):
        t.status = "open"
        db.add(AssignmentEvent(
            public_id=f"ASN-{t.public_id}-X{i:02}",
            ticket_id=t.id,
            agent_id=agent.id,
            queue_name="general",
            event_type="assigned",
            reason="test_fixture",
            created_at=t.created_at,
        ))
    db.flush()
    anomalies = detect_anomalies(db)
    assert any(a["scenario"] == "agent_beyond_capacity" for a in anomalies)


def test_anomaly_2_wrong_sla_calendar(db):
    """Detector 2: incorrect_channel_sla_calendar fires on calendar mismatch."""
    generate(db, tickets=3, messages=3, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    sla = next(e for e in t.sla_events if e.event_type == "created")
    original = t.channel.calendar_type
    t.channel.calendar_type = "24x7" if original == "business" else "business"
    db.flush()
    anomalies = detect_anomalies(db)
    assert any(a["scenario"] == "incorrect_channel_sla_calendar" for a in anomalies)


def test_anomaly_3_lost_reopening_history(db):
    """Detector 3: lost_reopening_history fires when reopened ticket has no event."""
    generate(db, tickets=2, messages=2, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    t.status = "reopened"
    for ev in list(t.sla_events):
        if ev.event_type == "reopened":
            db.delete(ev)
    db.flush()
    anomalies = detect_anomalies(db)
    assert any(a["scenario"] == "lost_reopening_history" for a in anomalies)


def test_anomaly_4_transfer_loop(db):
    """Detector 4: transfer_loop fires on A→B→A pattern."""
    generate(db, tickets=2, messages=2, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    agents = list(db.scalars(select(Agent).limit(2)))
    if len(agents) < 2:
        pytest.skip("Need 2+ agents")
    for i, ag in enumerate([agents[0], agents[1], agents[0]], 1):
        db.add(AssignmentEvent(
            public_id=f"ASN-{t.public_id}-T{i:02}",
            ticket_id=t.id,
            agent_id=ag.id,
            queue_name="general",
            event_type="transferred",
            reason="loop_test",
            created_at=t.created_at,
        ))
    db.flush()
    anomalies = detect_anomalies(db)
    assert any(a["scenario"] == "transfer_loop" for a in anomalies)


def test_anomaly_5_priority_contradicts_safety(db):
    """Detector 5: priority_contradicts_safety_rule fires on safety+non-urgent."""
    generate(db, tickets=2, messages=2, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    from tixora_route.models import Intent
    safety = next(i for i in db.scalars(select(Intent)) if i.name == "safety")
    t.intent = safety
    t.priority = "normal"
    db.flush()
    anomalies = detect_anomalies(db)
    assert any(a["scenario"] == "priority_contradicts_safety_rule" for a in anomalies)
