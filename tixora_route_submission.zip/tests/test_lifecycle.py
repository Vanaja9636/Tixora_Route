"""
Tests for ticket lifecycle management.

Verifies:
- resolve_ticket records Resolution and SLAEvent
- reopen_ticket preserves history and records reopened event
- escalate_ticket records escalation event
- transfer_ticket records transfer event
- History is never overwritten
- Lifecycle states change correctly
"""
import pytest
from datetime import datetime
from sqlalchemy import select
from tixora_route.generator import generate
from tixora_route.models import Ticket, SLAEvent, Resolution, AssignmentEvent
from tixora_route.lifecycle import resolve_ticket, reopen_ticket, escalate_ticket, transfer_ticket


def test_resolve_ticket(db):
    """Resolving a ticket must set status=resolved and create Resolution."""
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    resolve_ticket(db, t, summary="Fixed", code="fixed", satisfaction=4.5)
    db.flush()

    assert t.status == "resolved"
    assert t.resolved_at is not None
    assert t.resolution is not None
    assert t.resolution.resolution_code == "fixed"
    assert t.customer_satisfaction == 4.5


def test_resolve_records_sla_event(db):
    """Resolving must add a 'resolved' SLAEvent."""
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    resolve_ticket(db, t)
    db.flush()

    event_types = {e.event_type for e in t.sla_events}
    assert "resolved" in event_types


def test_reopen_preserves_history(db):
    """Reopening must preserve existing events and add a 'reopened' event."""
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))

    # Resolve first
    resolve_ticket(db, t)
    db.flush()
    events_before = len(t.sla_events)

    # Reopen
    reopen_ticket(db, t, reason="Customer requested")
    db.flush()

    assert t.status == "reopened"
    assert t.resolved_at is None
    # Must have more events (history preserved)
    assert len(t.sla_events) > events_before

    event_types = {e.event_type for e in t.sla_events}
    assert "created" in event_types
    assert "resolved" in event_types
    assert "reopened" in event_types


def test_full_lifecycle_history(db):
    """Full lifecycle: new → resolve → reopen → resolve has complete audit trail."""
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))

    resolve_ticket(db, t, summary="First resolve")
    db.flush()
    reopen_ticket(db, t, reason="Still broken")
    db.flush()
    resolve_ticket(db, t, summary="Second resolve", code="resolved2")
    db.flush()

    event_types = [e.event_type for e in t.sla_events]
    assert event_types.count("resolved") >= 1
    assert "reopened" in event_types


def test_escalate_ticket(db):
    """Escalating must set status=escalated and record SLAEvent."""
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    escalate_ticket(db, t, reason="SLA breach")
    db.flush()

    assert t.status == "escalated"
    event_types = {e.event_type for e in t.sla_events}
    assert "escalated" in event_types


def test_transfer_ticket(db):
    """Transferring must record an AssignmentEvent with event_type='transferred'."""
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    agents = list(db.scalars(select(from_model("Agent")).limit(2)))
    if len(agents) < 2:
        pytest.skip("Need at least 2 agents")

    transfer_ticket(db, t, agents[0], agents[1], reason="Load balancing")
    db.flush()

    transfers = [e for e in t.assignment_events if e.event_type == "transferred"]
    assert len(transfers) == 1
    assert "transferred" in transfers[0].reason or transfers[0].event_type == "transferred"


def from_model(name):
    import importlib
    m = importlib.import_module("tixora_route.models")
    return getattr(m, name)
