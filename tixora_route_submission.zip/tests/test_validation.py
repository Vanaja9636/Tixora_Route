"""
Tests for validation suite.

Verifies:
- Clean baseline passes strict validation
- Validation catches safety priority violations
- Validation catches missing messages
- Validation catches invalid enum values
- Counts match actual data
"""
import pytest
from sqlalchemy import select
from tixora_route.generator import generate
from tixora_route.validation import validate
from tixora_route.models import Ticket


def test_clean_baseline_valid(db):
    """Clean baseline with seed 20261022 must pass strict validation."""
    generate(db, tickets=10, messages=10, seed=20261022, agent_count=10)
    result = validate(db)
    assert result["valid"] is True
    assert result["issue_count"] == 0


def test_validation_returns_counts(db):
    """Validation must include row counts for all entities."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    result = validate(db)
    assert "counts" in result
    assert result["counts"]["tickets"] == 5


def test_validation_catches_safety_priority(db):
    """Validation must flag safety tickets with non-urgent priority."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    from tixora_route.models import Intent
    t = db.scalar(select(Ticket))
    safety = next(i for i in db.scalars(select(Intent)) if i.name == "safety")
    t.intent = safety
    t.priority = "normal"
    db.flush()
    result = validate(db)
    assert not result["valid"]
    codes = {issue["code"] for issue in result["issues"]}
    assert "SAFETY_PRIORITY_VIOLATION" in codes


def test_validation_structure(db):
    """Validation response must include valid, issue_count, issues, counts."""
    result = validate(db)
    assert "valid" in result
    assert "issue_count" in result
    assert "issues" in result
    assert "counts" in result
    assert isinstance(result["issues"], list)


def test_larger_clean_dataset(db):
    """50-ticket dataset with seed 20261022 must pass strict validation."""
    generate(db, tickets=50, messages=50, seed=20261022, agent_count=20)
    result = validate(db)
    assert result["valid"] is True, f"Expected valid=True, got issues: {result['issues']}"
