"""
Pytest fixtures for Tixora Route test suite.

Provides:
  - db: Fresh in-memory SQLite session per test
  - seeded_db: DB with 20-ticket seeded dataset for integration tests
"""
import pytest
from sqlalchemy import create_engine, event as sa_event
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from tixora_route.database import Base


@pytest.fixture
def db():
    """
    Fresh in-memory SQLite database for each test.
    Foreign key enforcement enabled.
    """
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )

    @sa_event.listens_for(engine, "connect")
    def set_sqlite_pragma(conn, rec):
        cur = conn.cursor()
        cur.execute("PRAGMA foreign_keys=ON")
        cur.close()

    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    session = Session()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()


@pytest.fixture
def seeded_db(db):
    """DB with 20 tickets and 20 messages pre-seeded with seed 20261022."""
    from tixora_route.generator import generate
    generate(db, tickets=20, messages=20, seed=20261022, agent_count=20)
    return db
