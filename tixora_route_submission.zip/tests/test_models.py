"""
Tests for SQLAlchemy data models and relationships.

Verifies:
- All 13 entities are registered
- Bridge tables exist
- Primary/foreign keys and uniqueness constraints
- Many-to-many relationships work correctly
"""
import pytest
from sqlalchemy import select, inspect
from tixora_route.models import (
    Base, Customer, Channel, Ticket, Message, Intent, Language,
    PriorityRule, Agent, Skill, Queue, AssignmentEvent, SLAEvent, Resolution,
)


def test_all_13_entities_registered():
    """All 13 required entities must be in the metadata."""
    required = {
        "customers", "channels", "tickets", "messages", "intents",
        "languages", "priority_rules", "agents", "skills", "queues",
        "assignment_events", "sla_events", "resolutions",
    }
    assert required.issubset(Base.metadata.tables)


def test_bridge_tables_exist():
    """Three M2M bridge tables must be registered."""
    bridges = {"customer_channels", "agent_skills", "queue_skills"}
    assert bridges.issubset(Base.metadata.tables)


def test_total_table_count():
    """13 entity tables + 3 bridge tables = 16 total tables."""
    assert len(Base.metadata.tables) >= 16


def test_ticket_has_public_id_unique():
    """Ticket.public_id column must have a unique constraint."""
    table = Base.metadata.tables["tickets"]
    unique_cols = set()
    for uc in table.constraints:
        if hasattr(uc, "columns"):
            for col in uc.columns:
                unique_cols.add(col.name)
    assert "public_id" in unique_cols or any(
        c.name == "public_id" and c.unique for c in table.columns
    )


def test_agent_has_public_id_unique():
    table = Base.metadata.tables["agents"]
    assert any(c.name == "public_id" and c.unique for c in table.columns)


def test_customer_email_unique():
    table = Base.metadata.tables["customers"]
    assert any(c.name == "email" and c.unique for c in table.columns)


def test_message_has_public_id_unique():
    table = Base.metadata.tables["messages"]
    assert any(c.name == "public_id" and c.unique for c in table.columns)


def test_sla_event_has_public_id_unique():
    table = Base.metadata.tables["sla_events"]
    assert any(c.name == "public_id" and c.unique for c in table.columns)


def test_ticket_indexes():
    """Tickets table must have indexes on status+priority and created_at."""
    indexes = {idx.name for idx in Base.metadata.tables["tickets"].indexes}
    assert "ix_tickets_status_priority" in indexes
    assert "ix_tickets_created_at" in indexes


def test_many_to_many_agent_skills(db):
    """Agent and Skill M2M relationship must work both ways."""
    from tixora_route.generator import generate
    generate(db, tickets=2, messages=2, seed=20261022, agent_count=4)
    agent = db.scalar(select(Agent))
    assert len(agent.skills) > 0
    skill = db.scalar(select(Skill))
    assert len(skill.agents) > 0


def test_ticket_cascade_delete(db):
    """Deleting a ticket cascades to messages, sla_events, assignment_events."""
    from tixora_route.generator import generate
    generate(db, tickets=2, messages=4, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    tid = t.id
    db.delete(t)
    db.commit()
    # Messages for that ticket should be gone
    remaining = db.scalars(select(Message).where(Message.ticket_id == tid)).all()
    assert len(remaining) == 0


def test_resolution_one_to_one(db):
    """Resolution has a one-to-one relationship with Ticket."""
    from tixora_route.generator import generate
    from tixora_route.lifecycle import resolve_ticket
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    resolve_ticket(db, t)
    db.flush()
    assert t.resolution is not None
    assert t.resolution.ticket_id == t.id


def test_ticket_public_id_is_immutable(db):
    """Public IDs cannot be rewritten after the row has been persisted."""
    from tixora_route.generator import generate
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    ticket = db.scalar(select(Ticket))
    ticket.public_id = "TKT-2026-999999"
    with pytest.raises(ValueError, match="immutable"):
        db.flush()
    db.rollback()
