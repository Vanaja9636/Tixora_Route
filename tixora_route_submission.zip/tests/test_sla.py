"""
Tests for business calendar and SLA computation.

Verifies:
- Business hours calendar skips nights/weekends
- 24x7 calendar is wall-clock
- SLA minutes computed per priority
- SLA creation events recorded with correct calendar
- Business elapsed time calculation
"""
import pytest
from datetime import datetime, timedelta
from tixora_route.calendar import add_sla_minutes, elapsed_business_minutes


class TestBusinessCalendar:
    def test_business_rolls_over_end_of_day(self):
        """60 minutes starting at 16:30 must roll to next day 09:30."""
        result = add_sla_minutes(datetime(2026, 1, 5, 16, 30), 60)
        assert result == datetime(2026, 1, 6, 9, 30)

    def test_business_within_day(self):
        """60 minutes from 10:00 must yield 11:00 same day."""
        result = add_sla_minutes(datetime(2026, 1, 5, 10, 0), 60)
        assert result == datetime(2026, 1, 5, 11, 0)

    def test_business_skips_weekend(self):
        """Minutes rolling past Friday 17:00 must skip to Monday 09:00."""
        # Friday 2026-01-02 at 16:00 + 120 min business = Mon 10:00
        result = add_sla_minutes(datetime(2026, 1, 2, 16, 0), 120)
        assert result == datetime(2026, 1, 5, 10, 0)

    def test_business_start_before_hours(self):
        """Minutes from before 09:00 must snap to 09:00 first."""
        result = add_sla_minutes(datetime(2026, 1, 5, 6, 0), 30)
        assert result == datetime(2026, 1, 5, 9, 30)

    def test_zero_minutes(self):
        """Zero minutes must return the start time unchanged."""
        start = datetime(2026, 1, 5, 10, 0)
        assert add_sla_minutes(start, 0) == start

    def test_urgent_30_minutes(self):
        """Urgent SLA (30 min) starting at 10:00 must be 10:30."""
        result = add_sla_minutes(datetime(2026, 1, 5, 10, 0), 30)
        assert result == datetime(2026, 1, 5, 10, 30)


class TestTwentyFourSeven:
    def test_247_spans_midnight(self):
        """24x7 60 minutes from 23:30 must yield 00:30 next day."""
        result = add_sla_minutes(datetime(2026, 1, 5, 23, 30), 60, "24x7")
        assert result == datetime(2026, 1, 6, 0, 30)

    def test_calendar_type(self):
        """'calendar' type must behave like 24x7."""
        result = add_sla_minutes(datetime(2026, 1, 5, 23, 30), 60, "calendar")
        assert result == datetime(2026, 1, 6, 0, 30)

    def test_247_weekend(self):
        """24x7 runs through weekends without interruption."""
        # Saturday 23:30 + 60 min
        result = add_sla_minutes(datetime(2026, 1, 3, 23, 30), 60, "24x7")
        assert result == datetime(2026, 1, 4, 0, 30)


class TestElapsedBusinessMinutes:
    def test_elapsed_zero_for_equal(self):
        t = datetime(2026, 1, 5, 10, 0)
        assert elapsed_business_minutes(t, t) == 0.0

    def test_elapsed_same_day(self):
        start = datetime(2026, 1, 5, 10, 0)
        end = datetime(2026, 1, 5, 11, 0)
        assert elapsed_business_minutes(start, end) == 60.0

    def test_elapsed_247(self):
        start = datetime(2026, 1, 5, 10, 0)
        end = datetime(2026, 1, 5, 11, 30)
        assert elapsed_business_minutes(start, end, "24x7") == 90.0


class TestSLACreation:
    def test_sla_event_created(self, db):
        from tixora_route.generator import generate
        from tixora_route.models import Ticket, SLAEvent
        from sqlalchemy import select
        generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
        tickets = list(db.scalars(select(Ticket)))
        for t in tickets:
            sla_events = [e for e in t.sla_events if e.event_type == "created"]
            assert len(sla_events) == 1, f"Ticket {t.public_id} must have exactly 1 SLA creation event"

    def test_sla_public_id_format(self, db):
        from tixora_route.generator import generate
        from tixora_route.models import Ticket, SLAEvent
        from sqlalchemy import select
        generate(db, tickets=3, messages=3, seed=20261022, agent_count=4)
        t = db.scalar(select(Ticket).where(Ticket.public_id == "TKT-2026-000001"))
        sla = next(e for e in t.sla_events if e.event_type == "created")
        assert sla.public_id == "SLA-TKT-2026-000001"

    def test_sla_records_calendar_in_details(self, db):
        from tixora_route.generator import generate
        from tixora_route.models import Ticket
        from sqlalchemy import select
        generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
        for t in db.scalars(select(Ticket)):
            for ev in t.sla_events:
                if ev.event_type == "created":
                    assert "calendar=" in ev.details
