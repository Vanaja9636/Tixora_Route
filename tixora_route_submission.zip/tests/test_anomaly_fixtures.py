import pytest

from tixora_route.anomalies import SCENARIOS, build_anomaly_fixture, close_anomaly_fixture
from tixora_route.validation import detect_anomalies


@pytest.mark.parametrize("scenario", sorted(SCENARIOS))
def test_isolated_anomaly_fixture_is_detected(scenario):
    engine, session = build_anomaly_fixture(scenario)
    try:
        found = detect_anomalies(session)
        assert scenario in {finding["scenario"] for finding in found}
    finally:
        close_anomaly_fixture(engine, session)
