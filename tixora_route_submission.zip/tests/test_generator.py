"""
Tests for deterministic synthetic data generation.

Verifies:
- Exact public ID formats
- Seed 20261022 produces same results each time
- Master records before child/event records
- Correct ticket/message/agent counts
- Realistic priority distributions
"""
import pytest
from sqlalchemy import select
from tixora_route.generator import generate
from tixora_route.models import Ticket, Message, Agent, Customer, Channel, Intent, Language


def test_generation_counts(db):
    """Generated counts must match requested parameters."""
    generate(db, tickets=12, messages=12, seed=20261022, agent_count=10)
    assert db.scalar(select(import_count(Ticket))) == 12
    assert db.scalar(select(import_count(Agent))) == 10


def import_count(cls):
    from sqlalchemy import func
    return func.count(cls.id)


def test_generation_ticket_count(db):
    generate(db, tickets=12, messages=12, seed=20261022, agent_count=10)
    from sqlalchemy import func, select as sel
    count = db.scalar(sel(func.count(Ticket.id)))
    assert count == 12


def test_exact_ticket_public_id_format(db):
    """Ticket public IDs must follow TKT-2026-NNNNNN format."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    ticket = db.scalar(select(Ticket).where(Ticket.public_id == "TKT-2026-000001"))
    assert ticket is not None
    ticket5 = db.scalar(select(Ticket).where(Ticket.public_id == "TKT-2026-000005"))
    assert ticket5 is not None


def test_exact_message_public_id_format(db):
    """First message public ID must follow MSG-TKT-2026-000001-001."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    msg = db.scalar(select(Message).where(Message.public_id == "MSG-TKT-2026-000001-001"))
    assert msg is not None


def test_exact_agent_public_id_format(db):
    """Agent public IDs must follow AGT-NNNNNN format."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=10)
    agent = db.scalar(select(Agent).where(Agent.public_id == "AGT-000001"))
    assert agent is not None
    agent10 = db.scalar(select(Agent).where(Agent.public_id == "AGT-000010"))
    assert agent10 is not None


def test_deterministic_seed(db):
    """Same seed must produce identical public IDs on two separate runs."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from tixora_route.database import Base

    engine2 = create_engine("sqlite://", connect_args={"check_same_thread": False})
    Base.metadata.create_all(engine2)
    db2 = sessionmaker(bind=engine2, expire_on_commit=False)()

    try:
        generate(db, tickets=10, messages=10, seed=20261022, agent_count=8)
        generate(db2, tickets=10, messages=10, seed=20261022, agent_count=8)

        ids1 = sorted([t.public_id for t in db.scalars(select(Ticket))])
        ids2 = sorted([t.public_id for t in db2.scalars(select(Ticket))])
        assert ids1 == ids2
    finally:
        db2.close()
        engine2.dispose()


def test_safety_tickets_always_urgent(db):
    """Safety intent tickets must always have urgent priority."""
    generate(db, tickets=50, messages=50, seed=20261022, agent_count=20)
    safety_tickets = db.scalars(
        select(Ticket).join(Intent, Intent.id == Ticket.intent_id).where(Intent.name == "safety")
    ).all()
    for t in safety_tickets:
        assert t.priority == "urgent", f"Safety ticket {t.public_id} has non-urgent priority {t.priority}"


def test_master_records_exist(db):
    """Reference master records (skills, channels, languages, intents) must be seeded."""
    from sqlalchemy import func
    generate(db, tickets=2, messages=2, seed=20261022, agent_count=4)
    from tixora_route.models import Skill, Channel, Language, Intent
    assert db.scalar(select(func.count(Skill.id))) >= 5
    assert db.scalar(select(func.count(Channel.id))) >= 5
    assert db.scalar(select(func.count(Language.id))) >= 4
    assert db.scalar(select(func.count(Intent.id))) >= 5


def test_each_ticket_has_sla_event(db):
    """Every ticket must have at least one SLAEvent."""
    from tixora_route.models import SLAEvent
    generate(db, tickets=10, messages=10, seed=20261022, agent_count=8)
    tickets = list(db.scalars(select(Ticket)))
    for t in tickets:
        assert t.sla_events, f"Ticket {t.public_id} has no SLA events"


def test_each_ticket_has_first_message(db):
    """Every ticket must have at least one customer message."""
    generate(db, tickets=10, messages=10, seed=20261022, agent_count=8)
    tickets = list(db.scalars(select(Ticket)))
    for t in tickets:
        assert t.messages, f"Ticket {t.public_id} has no messages"
        first = sorted(t.messages, key=lambda m: m.created_at)[0]
        assert first.sender_type == "customer"


def test_idempotent_seed(db):
    """Calling generate twice on same DB should not add duplicate data."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)  # should be idempotent
    from sqlalchemy import func
    count = db.scalar(select(func.count(Ticket.id)))
    assert count == 5  # still 5, not 10
