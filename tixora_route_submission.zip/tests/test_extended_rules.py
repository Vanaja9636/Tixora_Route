import json

from sqlalchemy import select

from tixora_route.generator import generate
from tixora_route.lifecycle import reopen_ticket, resolve_ticket
from tixora_route.models import AssignmentEvent, Message, SLAEvent, Ticket
from tixora_route.routing import route_ticket
from tixora_route.sla import escalate_if_due


def test_additional_messages_form_a_ticket_thread(db):
    generate(db, tickets=3, messages=30, seed=20261022, agent_count=8)
    messages = list(db.scalars(select(Message).order_by(Message.id)))
    replies = [message for message in messages if message.parent_message_id is not None]
    assert replies
    for reply in replies:
        assert reply.parent is not None
        assert reply.parent.ticket_id == reply.ticket_id
        assert reply.parent.created_at <= reply.created_at


def test_reopen_and_resolve_preserve_each_resolution(db):
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    ticket = db.scalar(select(Ticket))
    resolve_ticket(db, ticket, summary="First resolution", code="first")
    db.flush()
    reopen_ticket(db, ticket, reason="Still unresolved")
    db.flush()
    resolve_ticket(db, ticket, summary="Second resolution", code="second")
    db.flush()

    assert [resolution.resolution_code for resolution in ticket.resolutions] == [
        "first",
        "second",
    ]
    assert len({event.public_id for event in ticket.sla_events}) == len(ticket.sla_events)


def test_escalation_fires_once_at_sla_deadline(db):
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=4)
    ticket = db.scalar(select(Ticket))

    assert escalate_if_due(db, ticket, ticket.due_at)
    db.flush()
    assert ticket.status == "escalated"
    escalation_events = [
        event for event in ticket.sla_events if event.event_type == "escalated"
    ]
    assert len(escalation_events) == 1
    assert escalation_events[0].elapsed_business_minutes is not None
    assert not escalate_if_due(db, ticket, ticket.due_at)


def test_routing_audit_persists_score_and_rejected_reasons(db):
    generate(db, tickets=1, messages=1, seed=20261022, agent_count=8)
    ticket = db.scalar(select(Ticket))
    result = route_ticket(db, ticket)
    db.flush()

    event = db.scalar(
        select(AssignmentEvent).where(AssignmentEvent.ticket_id == ticket.id)
    )
    metadata = json.loads(event.decision_metadata)
    assert event.public_id == "ASN-TKT-2026-000001-001"
    assert isinstance(event.routing_score, float)
    assert "rejected_candidates" in metadata
    assert result["decision"] in {"assigned", "queued"}
