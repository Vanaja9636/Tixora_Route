"""
Tests for exports and metrics.

Verifies:
- Export produces all required files
- SHA-256 checksums are in source_manifest.json
- ground_truth.csv and ground_truth.json exist
- Metrics counts match actual data
- Reproducibility: two runs with same seed produce identical checksums
"""
import pytest
import json
import hashlib
from pathlib import Path
from sqlalchemy import select, func
from tixora_route.generator import generate
from tixora_route.exports import export_all, export_reproducibility_report
from tixora_route.metrics import get_metrics
from tixora_route.models import Ticket


def test_export_creates_required_files(db, tmp_path):
    """Export must create all required CSV and JSON files."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    result = export_all(db, str(tmp_path))

    required = {"tickets.csv", "messages.csv", "ground_truth.csv", "ground_truth.json"}
    for fname in required:
        assert fname in result["files"], f"Missing file: {fname}"
        assert (tmp_path / fname).exists(), f"File not created: {fname}"


def test_source_manifest_created(db, tmp_path):
    """export_all must create source_manifest.json with sha256 checksums."""
    generate(db, tickets=3, messages=3, seed=20261022, agent_count=4)
    export_all(db, str(tmp_path))

    manifest_path = tmp_path / "source_manifest.json"
    assert manifest_path.exists()
    manifest = json.loads(manifest_path.read_text())
    assert "algorithm" in manifest
    assert manifest["algorithm"] == "sha256"
    assert "files" in manifest


def test_checksums_are_valid_sha256(db, tmp_path):
    """All checksums in manifest must be valid 64-char hex strings."""
    generate(db, tickets=3, messages=3, seed=20261022, agent_count=4)
    result = export_all(db, str(tmp_path))

    for fname, chksum in result["checksums"].items():
        assert len(chksum) == 64, f"Bad checksum length for {fname}: {chksum!r}"
        assert all(c in "0123456789abcdef" for c in chksum), f"Not hex: {chksum!r}"


def test_ground_truth_not_used_in_routing(db, tmp_path):
    """ground_truth.csv must be labelled with 'label_source=business_rules'."""
    import csv
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    export_all(db, str(tmp_path))

    with open(tmp_path / "ground_truth.csv") as f:
        reader = csv.DictReader(f)
        rows = list(reader)
    assert len(rows) == 5
    for row in rows:
        assert row.get("label_source") == "business_rules"
        assert row.get("expected_decision") in {"assigned", "queued"}
        assert row.get("observed_decision") in {
            "assigned",
            "queued",
            "not_routed",
        }


def test_metrics_ticket_total(db):
    """get_metrics must return correct ticket total."""
    generate(db, tickets=7, messages=7, seed=20261022, agent_count=4)
    metrics = get_metrics(db)
    assert metrics["tickets_total"] == 7


def test_metrics_structure(db):
    """Metrics must include routing, sla, satisfaction, throughput fields."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=4)
    metrics = get_metrics(db)
    assert "routing" in metrics
    assert "sla" in metrics
    assert "satisfaction" in metrics
    assert "throughput" in metrics
    assert "agent_utilization" in metrics


def test_reproducibility_same_checksums(tmp_path):
    """Two runs with seed 20261022 must produce identical file checksums."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from tixora_route.database import Base

    checksums = []
    for run in range(2):
        engine = create_engine("sqlite://", connect_args={"check_same_thread": False})
        Base.metadata.create_all(engine)
        db = sessionmaker(bind=engine, expire_on_commit=False)()
        try:
            generate(db, tickets=10, messages=10, seed=20261022, agent_count=8)
            out_dir = tmp_path / f"run_{run}"
            out_dir.mkdir()
            result = export_all(db, str(out_dir))
            checksums.append(result["checksums"])
        finally:
            db.close()
            engine.dispose()

    # Compare checksums for tickets.csv
    assert checksums[0]["tickets.csv"] == checksums[1]["tickets.csv"], (
        "tickets.csv checksums differ between two runs with seed 20261022"
    )
    assert checksums[0]["agents.csv"] == checksums[1]["agents.csv"]
