"""
Tests for the explainable routing engine.

Verifies:
- Routing returns correct structure
- Skill matching enforced (RR-001)
- Language matching enforced (RR-002)
- Shift availability enforced (RR-003)
- Capacity limit enforced (RR-004)
- Assignment event recorded with correct public ID
- Deterministic selection (lowest load then public ID)
- Rejected candidates list populated
"""
import pytest
from datetime import datetime
from sqlalchemy import select
from tixora_route.generator import generate
from tixora_route.models import Ticket, Agent, AssignmentEvent
from tixora_route.routing import route_ticket


def test_route_returns_decision(db):
    """route_ticket must return a dict with 'decision' key."""
    generate(db, tickets=8, messages=8, seed=20261022, agent_count=20)
    t = db.scalar(select(Ticket))
    result = route_ticket(db, t)
    assert result["decision"] in ("assigned", "queued")


def test_route_has_explanation(db):
    """route_ticket must include explanation list."""
    generate(db, tickets=8, messages=8, seed=20261022, agent_count=20)
    t = db.scalar(select(Ticket))
    result = route_ticket(db, t)
    assert isinstance(result["explanation"], list)
    assert len(result["explanation"]) > 0


def test_route_includes_rejected_candidates(db):
    """route_ticket must include rejected_candidates list."""
    generate(db, tickets=8, messages=8, seed=20261022, agent_count=20)
    t = db.scalar(select(Ticket))
    result = route_ticket(db, t)
    assert "rejected_candidates" in result
    assert isinstance(result["rejected_candidates"], list)


def test_assigned_agent_has_required_skill(db):
    """Assigned agent must possess the ticket's required skill (RR-001)."""
    generate(db, tickets=20, messages=20, seed=20261022, agent_count=50)
    tickets = list(db.scalars(select(Ticket)))

    for t in tickets:
        result = route_ticket(db, t)
        if result["decision"] == "assigned":
            agent_pub_id = result["assigned_agent"]
            agent = db.scalar(select(Agent).where(Agent.public_id == agent_pub_id))
            assert agent is not None
            skill_names = {s.name for s in agent.skills}
            assert t.required_skill in skill_names, (
                f"Agent {agent_pub_id} lacks skill {t.required_skill!r}. Has: {skill_names}"
            )


def test_assigned_agent_language_matches(db):
    """Assigned agent must share the ticket's language (RR-002)."""
    generate(db, tickets=20, messages=20, seed=20261022, agent_count=50)
    for t in db.scalars(select(Ticket)):
        result = route_ticket(db, t)
        if result["decision"] == "assigned":
            agent = db.scalar(select(Agent).where(Agent.public_id == result["assigned_agent"]))
            assert agent.language_code == t.language.code


def test_assignment_event_recorded(db):
    """AssignmentEvent with correct public ID must be created on assignment."""
    generate(db, tickets=5, messages=5, seed=20261022, agent_count=20)
    t = db.scalar(select(Ticket).where(Ticket.public_id == "TKT-2026-000001"))
    result = route_ticket(db, t)
    db.commit()

    if result["decision"] == "assigned":
        ev = db.scalar(
            select(AssignmentEvent).where(AssignmentEvent.public_id == "ASN-TKT-2026-000001-001")
        )
        assert ev is not None
        assert ev.event_type == "assigned"


def test_capacity_not_exceeded(db):
    """Normal routing must never assign beyond an agent's capacity."""
    generate(db, tickets=50, messages=50, seed=20261022, agent_count=10)

    # Run routing for all tickets
    for t in db.scalars(select(Ticket)):
        route_ticket(db, t)
    db.commit()

    # Check no agent is over capacity
    from sqlalchemy import func
    rows = db.execute(
        select(
            AssignmentEvent.agent_id,
            Agent.public_id,
            Agent.capacity,
            func.count(AssignmentEvent.id).label("cnt"),
        )
        .join(Agent, Agent.id == AssignmentEvent.agent_id)
        .join(Ticket, Ticket.id == AssignmentEvent.ticket_id)
        .where(
            AssignmentEvent.event_type == "assigned",
            Ticket.status == "open",
        )
        .group_by(AssignmentEvent.agent_id, Agent.public_id, Agent.capacity)
    ).all()

    for _aid, pub_id, cap, cnt in rows:
        assert cnt <= cap, f"Agent {pub_id} exceeds capacity: {cnt} > {cap}"


def test_queued_when_no_eligible_agent(db):
    """If no agent can be matched, decision must be 'queued'."""
    generate(db, tickets=2, messages=2, seed=20261022, agent_count=4)
    t = db.scalar(select(Ticket))
    # Force impossible required skill
    t.required_skill = "nonexistent_skill_xyz"
    db.flush()
    result = route_ticket(db, t)
    assert result["decision"] == "queued"
    assert result["assigned_agent"] is None


def test_assignment_event_public_id_format(db):
    """AssignmentEvent public IDs must follow ASN-TKT-2026-NNNNNN-NNN format."""
    generate(db, tickets=3, messages=3, seed=20261022, agent_count=10)
    for t in db.scalars(select(Ticket)):
        route_ticket(db, t)
    db.commit()

    events = list(db.scalars(select(AssignmentEvent)))
    for ev in events:
        assert ev.public_id.startswith("ASN-TKT-2026-"), f"Bad ASN ID: {ev.public_id}"
