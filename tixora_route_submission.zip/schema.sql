-- Tixora Route schema; generated from src/tixora_route/models.py


CREATE TABLE channels (
	id INTEGER NOT NULL, 
	name VARCHAR(40) NOT NULL, 
	calendar_type VARCHAR(24) NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_channels_calendar_type CHECK (calendar_type IN ('business', 'calendar', '24x7')), 
	UNIQUE (name)
)

;

CREATE TABLE intents (
	id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	required_skill VARCHAR(60) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
)

;

CREATE TABLE languages (
	id INTEGER NOT NULL, 
	code VARCHAR(8) NOT NULL, 
	name VARCHAR(40) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (code)
)

;

CREATE TABLE skills (
	id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
)

;

CREATE TABLE agents (
	id INTEGER NOT NULL, 
	public_id VARCHAR(20) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	language_code VARCHAR(8) NOT NULL, 
	shift_start INTEGER NOT NULL, 
	shift_end INTEGER NOT NULL, 
	capacity INTEGER NOT NULL, 
	active BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_agents_shift_hours CHECK (shift_start >= 0 AND shift_end <= 24 AND shift_end > shift_start), 
	FOREIGN KEY(language_code) REFERENCES languages (code)
)

;
CREATE UNIQUE INDEX ix_agents_public_id ON agents (public_id);

CREATE TABLE customers (
	id INTEGER NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	email VARCHAR(180) NOT NULL, 
	language_code VARCHAR(8) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(language_code) REFERENCES languages (code)
)

;
CREATE UNIQUE INDEX ix_customers_email ON customers (email);

CREATE TABLE priority_rules (
	id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	intent_name VARCHAR(60) NOT NULL, 
	min_priority VARCHAR(16) NOT NULL, 
	safety_rule BOOLEAN NOT NULL, 
	effective_from DATETIME NOT NULL, 
	effective_to DATETIME, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_priority_rules_min_priority CHECK (min_priority IN ('low', 'normal', 'high', 'urgent')), 
	UNIQUE (name), 
	FOREIGN KEY(intent_name) REFERENCES intents (name)
)

;
CREATE INDEX ix_priority_rules_intent_name ON priority_rules (intent_name);

CREATE TABLE queues (
	id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	intent_name VARCHAR(60) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name), 
	FOREIGN KEY(intent_name) REFERENCES intents (name)
)

;
CREATE INDEX ix_queues_intent_name ON queues (intent_name);

CREATE TABLE agent_skills (
	agent_id INTEGER NOT NULL, 
	skill_id INTEGER NOT NULL, 
	PRIMARY KEY (agent_id, skill_id), 
	FOREIGN KEY(agent_id) REFERENCES agents (id) ON DELETE CASCADE, 
	FOREIGN KEY(skill_id) REFERENCES skills (id) ON DELETE CASCADE
)

;

CREATE TABLE customer_channels (
	customer_id INTEGER NOT NULL, 
	channel_id INTEGER NOT NULL, 
	PRIMARY KEY (customer_id, channel_id), 
	FOREIGN KEY(customer_id) REFERENCES customers (id) ON DELETE CASCADE, 
	FOREIGN KEY(channel_id) REFERENCES channels (id) ON DELETE CASCADE
)

;

CREATE TABLE queue_skills (
	queue_id INTEGER NOT NULL, 
	skill_id INTEGER NOT NULL, 
	PRIMARY KEY (queue_id, skill_id), 
	FOREIGN KEY(queue_id) REFERENCES queues (id) ON DELETE CASCADE, 
	FOREIGN KEY(skill_id) REFERENCES skills (id) ON DELETE CASCADE
)

;

CREATE TABLE tickets (
	id INTEGER NOT NULL, 
	public_id VARCHAR(30) NOT NULL, 
	customer_id INTEGER NOT NULL, 
	channel_id INTEGER NOT NULL, 
	intent_id INTEGER NOT NULL, 
	language_id INTEGER NOT NULL, 
	subject VARCHAR(240) NOT NULL, 
	priority VARCHAR(16) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	required_skill VARCHAR(60) NOT NULL, 
	created_at DATETIME NOT NULL, 
	due_at DATETIME NOT NULL, 
	resolved_at DATETIME, 
	customer_satisfaction FLOAT, 
	PRIMARY KEY (id), 
	CONSTRAINT ck_tickets_priority CHECK (priority IN ('low', 'normal', 'high', 'urgent')), 
	CONSTRAINT ck_tickets_status CHECK (status IN ('new', 'open', 'pending', 'escalated', 'resolved', 'reopened', 'closed')), 
	FOREIGN KEY(customer_id) REFERENCES customers (id), 
	FOREIGN KEY(channel_id) REFERENCES channels (id), 
	FOREIGN KEY(intent_id) REFERENCES intents (id), 
	FOREIGN KEY(language_id) REFERENCES languages (id)
)

;
CREATE INDEX ix_tickets_created_at ON tickets (created_at);
CREATE UNIQUE INDEX ix_tickets_public_id ON tickets (public_id);
CREATE INDEX ix_tickets_status ON tickets (status);
CREATE INDEX ix_tickets_status_priority ON tickets (status, priority);

CREATE TABLE assignment_events (
	id INTEGER NOT NULL, 
	public_id VARCHAR(64) NOT NULL, 
	ticket_id INTEGER NOT NULL, 
	agent_id INTEGER, 
	source_agent_id INTEGER, 
	queue_name VARCHAR(60) NOT NULL, 
	event_type VARCHAR(24) NOT NULL, 
	routing_score FLOAT NOT NULL, 
	reason TEXT NOT NULL, 
	decision_metadata TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (public_id), 
	FOREIGN KEY(ticket_id) REFERENCES tickets (id) ON DELETE CASCADE, 
	FOREIGN KEY(agent_id) REFERENCES agents (id), 
	FOREIGN KEY(source_agent_id) REFERENCES agents (id)
)

;
CREATE INDEX ix_assignment_agent_created ON assignment_events (agent_id, created_at);
CREATE INDEX ix_assignment_events_ticket_id ON assignment_events (ticket_id);
CREATE INDEX ix_assignment_ticket_created ON assignment_events (ticket_id, created_at);

CREATE TABLE messages (
	id INTEGER NOT NULL, 
	public_id VARCHAR(64) NOT NULL, 
	ticket_id INTEGER NOT NULL, 
	parent_message_id INTEGER, 
	sender_type VARCHAR(20) NOT NULL, 
	body TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(ticket_id) REFERENCES tickets (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_message_id) REFERENCES messages (id) ON DELETE SET NULL
)

;
CREATE UNIQUE INDEX ix_messages_public_id ON messages (public_id);
CREATE INDEX ix_messages_ticket_created ON messages (ticket_id, created_at);
CREATE INDEX ix_messages_ticket_id ON messages (ticket_id);

CREATE TABLE resolutions (
	id INTEGER NOT NULL, 
	ticket_id INTEGER NOT NULL, 
	summary TEXT NOT NULL, 
	resolution_code VARCHAR(40) NOT NULL, 
	resolved_at DATETIME NOT NULL, 
	customer_satisfaction FLOAT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(ticket_id) REFERENCES tickets (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_resolution_ticket_resolved ON resolutions (ticket_id, resolved_at);
CREATE INDEX ix_resolutions_ticket_id ON resolutions (ticket_id);

CREATE TABLE sla_events (
	id INTEGER NOT NULL, 
	public_id VARCHAR(64) NOT NULL, 
	ticket_id INTEGER NOT NULL, 
	event_type VARCHAR(24) NOT NULL, 
	due_at DATETIME NOT NULL, 
	created_at DATETIME NOT NULL, 
	elapsed_business_minutes FLOAT, 
	details TEXT NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (public_id), 
	FOREIGN KEY(ticket_id) REFERENCES tickets (id) ON DELETE CASCADE
)

;
CREATE INDEX ix_sla_events_ticket_id ON sla_events (ticket_id);
CREATE INDEX ix_sla_ticket_created ON sla_events (ticket_id, created_at);
CREATE INDEX ix_sla_type_created ON sla_events (event_type, created_at);
