"""
Deterministic synthetic data generator for Tixora Route.

Seed: 20261022 (fixed for reproducibility)
Scale:
  - Quick demo: 100 tickets, 300 messages, 100 agents
  - Full: 30,000 tickets, 100,000 messages, 100 agents, 90 days

Generation order (master before child before event records):
  1. Skills, Languages, Channels, Intents, Queues, PriorityRules
  2. Customers (with channel associations)
  3. Agents (with skill associations)
  4. Tickets (batched)
  5. Messages (per ticket + additional)
  6. SLAEvents (per ticket)

All public IDs are zero-padded and immutable after creation.
Ground-truth labels are derived from business rules, not random assignment.
"""
import random
from datetime import datetime, timedelta
from sqlalchemy import select, func
from .models import (
    Customer, Channel, Intent, Language, PriorityRule,
    Agent, Skill, Queue, Ticket, Message, SLAEvent,
)
from .taxonomy import INTENTS, LANGUAGES, CHANNELS, SUBJECTS, MESSAGE_BODIES, PRIORITY_WEIGHTS
from .priority import enforce_priority
from .sla import calculate_due, record_sla

BASE_DATE = datetime(2026, 1, 1, 9, 0, 0)  # Simulation start: 2026-01-01 09:00 UTC


def seed_reference_data(db, rng: random.Random, agent_count: int = 100) -> None:
    """
    Seed master reference records: skills, languages, channels, intents,
    queues, priority rules, customers, and agents.

    Idempotent: skips if customers already exist.
    """
    if db.scalar(select(func.count(Customer.id))):
        return

    # 1. Skills
    skills = {
        n: Skill(name=n) for n in sorted(set(INTENTS.values()) | {"general"})
    }
    db.add_all(skills.values())

    # 2. Languages
    langs = {c: Language(code=c, name=n) for c, n in LANGUAGES.items()}
    db.add_all(langs.values())

    # 3. Channels
    chans = {n: Channel(name=n, calendar_type=cal) for n, cal in CHANNELS.items()}
    db.add_all(chans.values())

    # 4. Intents
    intents = {n: Intent(name=n, required_skill=s) for n, s in INTENTS.items()}
    intents["general"] = Intent(name="general", required_skill="general")
    db.add_all(intents.values())

    # 5. Queues: one per intent + general
    db.add_all([Queue(name=n + "_queue", intent_name=n) for n in INTENTS])
    db.add(Queue(name="general", intent_name="general"))

    # 6. Priority rules
    for n in INTENTS:
        is_safety = (n == "safety")
        db.add(PriorityRule(
            name=f"{n}_baseline",
            intent_name=n,
            min_priority="urgent" if is_safety else "normal",
            safety_rule=is_safety,
            effective_from=BASE_DATE,
        ))

    # 7. Customers (100 master records, each linked to all channels)
    lang_codes = list(LANGUAGES)
    all_channels = list(chans.values())
    customers = [
        Customer(
            name=f"Customer {i:05}",
            email=f"customer{i:05}@example.test",
            language_code=rng.choice(lang_codes),
            channels=all_channels,
        )
        for i in range(1, 101)
    ]
    db.add_all(customers)
    db.flush()

    # 8. Agents with skill assignments
    skill_values = list(skills.values())
    language_list = list(LANGUAGES.keys())
    max_k = len(skill_values)

    for i in range(1, agent_count + 1):
        lang_code = language_list[(i - 1) % len(language_list)]
        # Each agent gets 2–max_k skills (at least 2 for coverage)
        k = rng.randint(2, max_k)
        agent_skills = rng.sample(skill_values, k=k)
        db.add(Agent(
            public_id=f"AGT-{i:06}",
            name=f"Agent {i:03}",
            language_code=lang_code,
            shift_start=9,
            shift_end=17,
            capacity=8,
            active=True,
            skills=agent_skills,
        ))

    # 9. Assign all skills to all queues (queues are skill-agnostic buckets)
    for q in db.scalars(select(Queue)):
        q.skills = skill_values

    db.commit()


def generate(
    db,
    tickets: int = 100,
    messages: int = 300,
    seed: int = 20261022,
    agent_count: int = 100,
    event_days: int = 90,
    batch_size: int = 1000,
) -> dict:
    """
    Generate deterministic synthetic data.

    Args:
        db: SQLAlchemy session
        tickets: Number of tickets to generate
        messages: Total messages (including per-ticket first messages)
        seed: RNG seed (fixed: 20261022)
        agent_count: Number of agents to create
        event_days: Simulation span in days (90 default)
        batch_size: DB flush batch size for efficiency

    Returns:
        Summary dict with row counts and seed.
    """
    if tickets < 0 or messages < 0 or agent_count < 1 or event_days < 1 or batch_size < 1:
        raise ValueError(
            "tickets/messages must be non-negative; agents, event_days, and batch_size "
            "must be positive."
        )

    rng = random.Random(seed)
    seed_reference_data(db, rng, agent_count)

    existing_ticket_count = db.scalar(select(func.count(Ticket.id))) or 0
    if existing_ticket_count:
        if existing_ticket_count != tickets:
            raise ValueError(
                "The database already contains generated tickets; use a fresh database "
                "to generate a different dataset."
            )
        return {
            "tickets": existing_ticket_count,
            "agents": db.scalar(select(func.count(Agent.id))) or 0,
            "messages": db.scalar(select(func.count(Message.id))) or 0,
            "seed": seed,
            "event_days": event_days,
            "already_generated": True,
        }

    customers = list(db.scalars(select(Customer)))
    channels = list(db.scalars(select(Channel)))
    intents = [
        intent for intent in db.scalars(select(Intent))
        if intent.name in INTENTS
    ]
    langs = list(db.scalars(select(Language)))

    total_span_minutes = event_days * 1440

    # Generate tickets in batches
    for batch_start in range(1, tickets + 1, batch_size):
        batch_end = min(tickets + 1, batch_start + batch_size)
        batch = []

        for i in range(batch_start, batch_end):
            intent = rng.choice(intents)
            lang = rng.choice(langs)
            channel = rng.choice(channels)

            # Use intent-specific priority weights
            weights = PRIORITY_WEIGHTS.get(intent.name, [10, 55, 25, 10])
            raw_priority = rng.choices(["low", "normal", "high", "urgent"], weights)[0]
            priority, _ = enforce_priority(intent.name, raw_priority)

            created = BASE_DATE + timedelta(minutes=rng.randint(0, total_span_minutes))

            # Realistic subject
            subject_pool = SUBJECTS.get(intent.name, [f"{intent.name} request {i}"])
            subject = rng.choice(subject_pool) + f" #{i}"

            ticket = Ticket(
                public_id=f"TKT-2026-{i:06}",
                customer_id=rng.choice(customers).id,
                channel=channel,
                intent_id=intent.id,
                language_id=lang.id,
                subject=subject,
                priority=priority,
                status="new",
                required_skill=intent.required_skill,
                created_at=created,
            )
            ticket.due_at = calculate_due(ticket)
            batch.append(ticket)

        db.add_all(batch)
        db.flush()

        for t in batch:
            # Compute proper SLA deadline
            record_sla(db, t, t.due_at)

            # First message: always from customer
            body_pool = MESSAGE_BODIES["customer"]
            db.add(Message(
                public_id=f"MSG-{t.public_id}-001",
                ticket_id=t.id,
                sender_type="customer",
                body=rng.choice(body_pool),
                created_at=t.created_at,
            ))

        db.commit()

    # Generate additional messages beyond first-per-ticket
    tickets_by_id = {
        ticket.id: ticket
        for ticket in db.scalars(select(Ticket).order_by(Ticket.id))
    }
    ticket_ids = list(tickets_by_id)
    last_message_by_ticket = {
        message.ticket_id: message
        for message in db.scalars(select(Message).order_by(Message.id))
    }
    message_counts = {ticket_id: 1 for ticket_id in tickets_by_id}
    additional_messages = []
    for _ in range(max(0, messages - tickets)):
        if not tickets_by_id:
            break
        ticket_id = rng.choice(ticket_ids)
        ticket = tickets_by_id[ticket_id]
        message_counts[ticket_id] += 1
        sequence = message_counts[ticket_id]
        sender = rng.choice(["customer", "agent", "system"])
        message = Message(
            public_id=f"MSG-{ticket.public_id}-{sequence:03}",
            ticket=ticket,
            parent=last_message_by_ticket[ticket_id],
            sender_type=sender,
            body=rng.choice(MESSAGE_BODIES[sender]),
            created_at=ticket.created_at + timedelta(minutes=sequence * 5),
        )
        additional_messages.append(message)
        last_message_by_ticket[ticket_id] = message
        if len(additional_messages) >= batch_size:
            db.add_all(additional_messages)
            db.flush()
            additional_messages.clear()

    if additional_messages:
        db.add_all(additional_messages)
    db.commit()

    return {
        "tickets": tickets,
        "agents": agent_count,
        "messages": max(tickets, messages),
        "seed": seed,
        "event_days": event_days,
    }
