"""Tixora Route — Intelligent Ticket Routing and SLA Management Platform."""
__version__ = "1.0.0"
__title__ = "Tixora Route"
