"""
Metrics aggregation for Tixora Route.

Computes: ticket counts by status/priority/channel/intent,
assignment rates, SLA breach rates, average resolution time,
routing outcomes, and agent utilization.
"""
from sqlalchemy import select, func
from .models import Ticket, Message, Agent, AssignmentEvent, SLAEvent, Resolution


def get_metrics(db) -> dict:
    """
    Return comprehensive platform metrics derived from source records.

    All values are computed from database records using documented business
    rules — no ground-truth labels are used.
    """
    total_tickets = db.scalar(select(func.count(Ticket.id))) or 0
    total_messages = db.scalar(select(func.count(Message.id))) or 0
    total_agents = db.scalar(select(func.count(Agent.id))) or 0
    total_assignments = db.scalar(select(func.count(AssignmentEvent.id))) or 0
    total_sla_events = db.scalar(select(func.count(SLAEvent.id))) or 0
    total_resolutions = db.scalar(select(func.count(Resolution.id))) or 0

    # Breakdowns
    by_status = dict(
        db.execute(
            select(Ticket.status, func.count(Ticket.id)).group_by(Ticket.status)
        ).all()
    )
    by_priority = dict(
        db.execute(
            select(Ticket.priority, func.count(Ticket.id)).group_by(Ticket.priority)
        ).all()
    )
    by_sla_event_type = dict(
        db.execute(
            select(SLAEvent.event_type, func.count(SLAEvent.id)).group_by(SLAEvent.event_type)
        ).all()
    )
    by_assignment_type = dict(
        db.execute(
            select(AssignmentEvent.event_type, func.count(AssignmentEvent.id)).group_by(AssignmentEvent.event_type)
        ).all()
    )

    # Routing outcomes use each ticket's latest decision, not event-row totals.
    latest_decision_by_ticket = {}
    for ticket_id, event_type in db.execute(
        select(AssignmentEvent.ticket_id, AssignmentEvent.event_type).order_by(
            AssignmentEvent.ticket_id,
            AssignmentEvent.created_at,
            AssignmentEvent.id,
        )
    ):
        latest_decision_by_ticket[ticket_id] = event_type
    assigned_count = sum(
        event_type in {"assigned", "transferred"}
        for event_type in latest_decision_by_ticket.values()
    )
    queued_count = sum(
        event_type == "queued" for event_type in latest_decision_by_ticket.values()
    )
    routed_count = assigned_count + queued_count
    assignment_rate = round(assigned_count / routed_count, 4) if routed_count else 0.0

    # SLA breach count
    sla_breached = by_sla_event_type.get("breached", 0)
    sla_breach_rate = round(sla_breached / total_tickets, 4) if total_tickets > 0 else 0.0

    # Average customer satisfaction (from resolutions)
    resolutions = list(db.scalars(select(Resolution)))
    rated = [r.customer_satisfaction for r in resolutions if r.customer_satisfaction is not None]
    avg_satisfaction = round(sum(rated) / len(rated), 4) if rated else None

    # Agent utilization (assigned tickets per agent)
    from .routing import _agent_load

    active_load = _agent_load(db)
    avg_load = (
        round(sum(active_load.values()) / total_agents, 4)
        if total_agents > 0
        else 0.0
    )

    # Messages per ticket
    avg_messages = round(total_messages / total_tickets, 4) if total_tickets > 0 else 0.0

    return {
        "tickets_total": total_tickets,
        "messages_total": total_messages,
        "agents_total": total_agents,
        "assignments_total": total_assignments,
        "sla_events_total": total_sla_events,
        "resolutions_total": total_resolutions,
        "tickets_by_status": by_status,
        "tickets_by_priority": by_priority,
        "sla_events_by_type": by_sla_event_type,
        "assignment_events_by_type": by_assignment_type,
        "routing": {
            "routed": routed_count,
            "assigned": assigned_count,
            "queued": queued_count,
            "assignment_rate": assignment_rate,
        },
        "sla": {
            "breached": sla_breached,
            "breach_rate": sla_breach_rate,
        },
        "satisfaction": {
            "average": avg_satisfaction,
            "rated_resolutions": len(rated),
        },
        "agent_utilization": {
            "avg_load_per_agent": avg_load,
        },
        "throughput": {
            "avg_messages_per_ticket": avg_messages,
        },
    }
