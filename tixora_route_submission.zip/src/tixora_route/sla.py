"""
SLA computation and event recording for Tixora Route.

SLA deadlines are computed from the ticket creation time using the
channel-specific calendar type. The SLA public ID is stable and
immutable: SLA-{ticket_public_id}.

SLA Minutes by Priority:
  - urgent  : 30 business minutes
  - high    : 120 business minutes
  - normal  : 240 business minutes
  - low     : 480 business minutes

Calendar types are taken from the ticket's channel at creation time
and recorded in the SLAEvent.details field for audit purposes.
"""
from datetime import datetime, timezone
from .calendar import add_sla_minutes, elapsed_business_minutes
from .models import SLAEvent

# SLA response time targets (business minutes)
SLA_MINUTES = {
    "urgent": 30,
    "high": 120,
    "normal": 240,
    "low": 480,
}


def _now_utc_naive() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _unique_event_id(ticket, suffix: str) -> str:
    base = f"SLA-{ticket.public_id}-{suffix}"
    existing = {event.public_id for event in ticket.sla_events}
    if base not in existing:
        return base
    sequence = 2
    while f"{base}-{sequence:03}" in existing:
        sequence += 1
    return f"{base}-{sequence:03}"


def calculate_due(ticket, config: dict | None = None) -> datetime:
    """
    Calculate the SLA due datetime for a ticket.

    Uses the ticket's channel calendar type and priority to determine
    elapsed business minutes from creation.
    """
    cfg = config or {}
    priority_minutes = {
        "urgent": cfg.get("urgent_minutes", SLA_MINUTES["urgent"]),
        "high": cfg.get("high_minutes", SLA_MINUTES["high"]),
        "normal": cfg.get("default_minutes", SLA_MINUTES["normal"]),
        "low": cfg.get("low_minutes", SLA_MINUTES["low"]),
    }
    minutes = priority_minutes.get(ticket.priority, SLA_MINUTES["normal"])
    cal = ticket.channel.calendar_type
    return add_sla_minutes(ticket.created_at, minutes, cal)


def record_sla(session, ticket, due_at: datetime) -> SLAEvent:
    """
    Record an SLA creation event. Stores channel calendar in details
    for future anomaly detection (calendar drift).
    """
    ev = SLAEvent(
        public_id=f"SLA-{ticket.public_id}",
        ticket=ticket,
        event_type="created",
        due_at=due_at,
        created_at=ticket.created_at,
        details=(
            f"calendar={ticket.channel.calendar_type};"
            f"priority={ticket.priority};"
            f"sla_minutes={SLA_MINUTES.get(ticket.priority, 240)}"
        ),
    )
    ticket.due_at = due_at
    session.add(ev)
    return ev


def record_sla_breach(session, ticket, at: datetime | None = None) -> SLAEvent:
    """Record that an SLA deadline was breached."""
    now = at or _now_utc_naive()
    ev = SLAEvent(
        public_id=_unique_event_id(ticket, "BREACH"),
        ticket=ticket,
        event_type="breached",
        due_at=ticket.due_at,
        created_at=now,
        elapsed_business_minutes=elapsed_business_minutes(
            ticket.created_at, now, ticket.channel.calendar_type
        ),
        details=f"SLA breached at {now.isoformat()}",
    )
    session.add(ev)
    return ev


def record_sla_escalation(session, ticket, at: datetime | None = None) -> SLAEvent:
    """Record an SLA escalation event."""
    now = at or _now_utc_naive()
    ev = SLAEvent(
        public_id=_unique_event_id(ticket, "ESC"),
        ticket=ticket,
        event_type="escalated",
        due_at=ticket.due_at,
        created_at=now,
        elapsed_business_minutes=elapsed_business_minutes(
            ticket.created_at, now, ticket.channel.calendar_type
        ),
        details=f"Ticket escalated at {now.isoformat()}",
    )
    session.add(ev)
    return ev


def is_sla_breached(ticket, at: datetime | None = None) -> bool:
    """Return True if the ticket's SLA deadline has passed."""
    check_time = at or _now_utc_naive()
    return ticket.due_at is not None and check_time > ticket.due_at


def is_escalation_due(
    ticket,
    at: datetime,
    escalation_fraction: float = 0.8,
) -> bool:
    """Return whether the configured fraction of a business-calendar SLA elapsed."""
    if not 0 < escalation_fraction <= 1:
        raise ValueError("escalation_fraction must be greater than 0 and at most 1")
    if ticket.status in {"resolved", "closed"}:
        return False
    elapsed = elapsed_business_minutes(
        ticket.created_at, at, ticket.channel.calendar_type
    )
    threshold = SLA_MINUTES.get(ticket.priority, SLA_MINUTES["normal"])
    return elapsed >= threshold * escalation_fraction


def escalate_if_due(
    session,
    ticket,
    at: datetime,
    escalation_fraction: float = 0.8,
) -> bool:
    """Escalate once when the business-time warning threshold is reached."""
    if not is_escalation_due(ticket, at, escalation_fraction):
        return False
    if any(event.event_type == "escalated" for event in ticket.sla_events):
        return False
    ticket.status = "escalated"
    record_sla_escalation(session, ticket, at)
    return True
