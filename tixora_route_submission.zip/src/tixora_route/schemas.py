"""
Pydantic schemas for Tixora Route API (v2 style).

Request/response models with validation, pagination, and
correct HTTP semantics.
"""
from __future__ import annotations
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, Field, ConfigDict


# ── Shared ──────────────────────────────────────────────────────────────────

class PaginationParams(BaseModel):
    """Pagination query parameters."""
    skip: int = Field(default=0, ge=0, description="Number of records to skip")
    limit: int = Field(default=100, ge=1, le=1000, description="Max records to return")


# ── Ticket Schemas ───────────────────────────────────────────────────────────

class TicketCreate(BaseModel):
    """Request body for creating a ticket via POST /tickets."""
    customer_id: int = Field(..., description="Customer internal ID")
    channel_id: int = Field(..., description="Channel internal ID")
    intent_id: int = Field(..., description="Intent internal ID")
    language_id: int = Field(..., description="Language internal ID")
    subject: str = Field(..., min_length=1, max_length=240)
    priority: str = Field(default="normal", pattern="^(low|normal|high|urgent)$")
    required_skill: str = Field(..., min_length=1, max_length=60)


class TicketOut(BaseModel):
    """Response schema for a single ticket."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    public_id: str
    subject: str
    priority: str
    status: str
    required_skill: str
    created_at: datetime
    due_at: datetime
    resolved_at: Optional[datetime] = None
    customer_satisfaction: Optional[float] = None


class TicketListOut(BaseModel):
    """Paginated ticket list response."""
    total: int
    skip: int
    limit: int
    items: List[TicketOut]


class TicketDetailOut(BaseModel):
    ticket: TicketOut
    message_count: int
    assignment_count: int


# ── Message Schemas ──────────────────────────────────────────────────────────

class MessageOut(BaseModel):
    """Response schema for a single message."""
    model_config = ConfigDict(from_attributes=True)

    public_id: str
    sender_type: str
    body: str
    created_at: datetime


# ── Agent Schemas ────────────────────────────────────────────────────────────

class AgentOut(BaseModel):
    """Response schema for an agent."""
    model_config = ConfigDict(from_attributes=True)

    public_id: str
    name: str
    language_code: str
    shift_start: int
    shift_end: int
    capacity: int
    active: bool


class AgentListOut(BaseModel):
    """Paginated agent list response."""
    total: int
    skip: int
    limit: int
    items: List[AgentOut]


# ── Queue Schemas ────────────────────────────────────────────────────────────

class QueueOut(BaseModel):
    """Response schema for a queue."""
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    intent_name: str


# ── History Schemas ──────────────────────────────────────────────────────────

class HistoryEntryOut(BaseModel):
    """A single entry in ticket history (assignment or SLA event)."""
    event_type: str
    event_kind: str  # 'assignment' or 'sla'
    public_id: str
    occurred_at: datetime
    detail: str


# ── Routing Schemas ──────────────────────────────────────────────────────────

class RouteResult(BaseModel):
    """Response from POST /tickets/{ticket_id}/route."""
    ticket_id: str
    assigned_agent: Optional[str]
    queue: str
    explanation: List[str]
    eligible_candidates: int
    rejected_candidates: List[dict] = Field(default_factory=list)
    decision: str  # 'assigned' or 'queued'


# ── Validation Schemas ───────────────────────────────────────────────────────

class ValidationResult(BaseModel):
    """Response from POST /validate."""
    valid: bool
    issue_count: int
    issues: List[dict]
    counts: dict


# ── Health Schema ────────────────────────────────────────────────────────────

class HealthOut(BaseModel):
    """Response from GET /health."""
    status: str
    service: str
    version: str


class MetricsOut(BaseModel):
    tickets_total: int
    messages_total: int
    agents_total: int
    assignments_total: int
    sla_events_total: int
    resolutions_total: int
    tickets_by_status: dict[str, int]
    tickets_by_priority: dict[str, int]
    sla_events_by_type: dict[str, int]
    assignment_events_by_type: dict[str, int]
    routing: dict[str, int | float]
    sla: dict[str, int | float]
    satisfaction: dict[str, int | float | None]
    agent_utilization: dict[str, int | float]
    throughput: dict[str, int | float]
