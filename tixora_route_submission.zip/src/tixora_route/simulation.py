"""
Simulation runner for Tixora Route.

Routes all unassigned (status='new') tickets through the routing engine.
Records decisions, counts, and returns a summary.
"""
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from .models import Agent, Queue, Ticket
from .routing import _agent_load, route_ticket


def simulate(db, limit: int | None = None, include_decisions: bool = True) -> dict:
    """
    Route all 'new' tickets using the explainable routing engine.

    Args:
        db: SQLAlchemy session
        limit: Optional max tickets to process (for testing)

    Returns:
        Summary dict with processed, assigned, queued counts, and decisions.
    """
    if limit is not None and limit < 0:
        raise ValueError("limit must be non-negative")
    stmt = (
        select(Ticket)
        .options(
            selectinload(Ticket.intent),
            selectinload(Ticket.language),
            selectinload(Ticket.channel),
            selectinload(Ticket.assignment_events),
        )
        .where(Ticket.status == "new")
        .order_by(Ticket.id)
    )
    if limit is not None:
        stmt = stmt.limit(limit)

    agents = list(db.scalars(
        select(Agent)
        .options(selectinload(Agent.skills))
        .where(Agent.active.is_(True))
        .order_by(Agent.public_id)
    ))
    queue_by_intent = {
        queue.intent_name: queue.name for queue in db.scalars(select(Queue))
    }
    current_load = _agent_load(db)
    results = []
    assigned = 0
    queued = 0
    for t in db.scalars(stmt):
        r = route_ticket(
            db,
            t,
            agents=agents,
            current_load=current_load,
            queue_by_intent=queue_by_intent,
        )
        if r["decision"] == "assigned":
            assigned += 1
        else:
            queued += 1
        if include_decisions:
            results.append(r)

    db.commit()

    return {
        "processed": assigned + queued,
        "assigned": assigned,
        "queued": queued,
        "assignment_rate": round(assigned / (assigned + queued), 4) if assigned + queued else 0.0,
        "decisions": results,
    }
