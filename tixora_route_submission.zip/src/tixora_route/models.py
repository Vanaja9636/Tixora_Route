"""SQLAlchemy data model for the Tixora Route ticket-routing platform."""

from datetime import datetime

from sqlalchemy import (
    Boolean,
    CheckConstraint,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Table,
    Text,
    event as sqlalchemy_event,
    inspect as sqlalchemy_inspect,
)
from sqlalchemy.orm import Mapped, Session, mapped_column, relationship

from .database import Base


customer_channels = Table(
    "customer_channels",
    Base.metadata,
    Column("customer_id", ForeignKey("customers.id", ondelete="CASCADE"), primary_key=True),
    Column("channel_id", ForeignKey("channels.id", ondelete="CASCADE"), primary_key=True),
)
agent_skills = Table(
    "agent_skills",
    Base.metadata,
    Column("agent_id", ForeignKey("agents.id", ondelete="CASCADE"), primary_key=True),
    Column("skill_id", ForeignKey("skills.id", ondelete="CASCADE"), primary_key=True),
)
queue_skills = Table(
    "queue_skills",
    Base.metadata,
    Column("queue_id", ForeignKey("queues.id", ondelete="CASCADE"), primary_key=True),
    Column("skill_id", ForeignKey("skills.id", ondelete="CASCADE"), primary_key=True),
)


class Customer(Base):
    __tablename__ = "customers"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    email: Mapped[str] = mapped_column(String(180), unique=True, nullable=False, index=True)
    language_code: Mapped[str] = mapped_column(
        String(8), ForeignKey("languages.code"), nullable=False, default="en"
    )

    channels: Mapped[list["Channel"]] = relationship(
        secondary=customer_channels, back_populates="customers"
    )
    tickets: Mapped[list["Ticket"]] = relationship(back_populates="customer")


class Channel(Base):
    __tablename__ = "channels"
    __table_args__ = (
        CheckConstraint(
            "calendar_type IN ('business', 'calendar', '24x7')",
            name="ck_channels_calendar_type",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(40), unique=True, nullable=False)
    calendar_type: Mapped[str] = mapped_column(String(24), nullable=False, default="business")

    customers: Mapped[list["Customer"]] = relationship(
        secondary=customer_channels, back_populates="channels"
    )
    tickets: Mapped[list["Ticket"]] = relationship(back_populates="channel")


class Intent(Base):
    __tablename__ = "intents"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)
    required_skill: Mapped[str] = mapped_column(String(60), nullable=False)

    tickets: Mapped[list["Ticket"]] = relationship(back_populates="intent")


class Language(Base):
    __tablename__ = "languages"

    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(8), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(40), nullable=False)

    tickets: Mapped[list["Ticket"]] = relationship(back_populates="language")


class PriorityRule(Base):
    __tablename__ = "priority_rules"
    __table_args__ = (
        CheckConstraint(
            "min_priority IN ('low', 'normal', 'high', 'urgent')",
            name="ck_priority_rules_min_priority",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    intent_name: Mapped[str] = mapped_column(
        String(60), ForeignKey("intents.name"), nullable=False, index=True
    )
    min_priority: Mapped[str] = mapped_column(String(16), nullable=False)
    safety_rule: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    effective_from: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    effective_to: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class Agent(Base):
    __tablename__ = "agents"
    __table_args__ = (
        CheckConstraint(
            "shift_start >= 0 AND shift_end <= 24 AND shift_end > shift_start",
            name="ck_agents_shift_hours",
        ),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    language_code: Mapped[str] = mapped_column(
        String(8), ForeignKey("languages.code"), nullable=False, default="en"
    )
    shift_start: Mapped[int] = mapped_column(Integer, nullable=False, default=9)
    shift_end: Mapped[int] = mapped_column(Integer, nullable=False, default=17)
    capacity: Mapped[int] = mapped_column(Integer, nullable=False, default=8)
    active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    skills: Mapped[list["Skill"]] = relationship(
        secondary=agent_skills, back_populates="agents"
    )
    assignments: Mapped[list["AssignmentEvent"]] = relationship(
        back_populates="agent", foreign_keys="AssignmentEvent.agent_id"
    )
    source_assignments: Mapped[list["AssignmentEvent"]] = relationship(
        back_populates="source_agent", foreign_keys="AssignmentEvent.source_agent_id"
    )


class Skill(Base):
    __tablename__ = "skills"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)

    agents: Mapped[list["Agent"]] = relationship(
        secondary=agent_skills, back_populates="skills"
    )
    queues: Mapped[list["Queue"]] = relationship(
        secondary=queue_skills, back_populates="skills"
    )


class Queue(Base):
    __tablename__ = "queues"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(60), unique=True, nullable=False)
    intent_name: Mapped[str] = mapped_column(
        String(60), ForeignKey("intents.name"), nullable=False, index=True
    )

    skills: Mapped[list["Skill"]] = relationship(
        secondary=queue_skills, back_populates="queues"
    )


class Ticket(Base):
    __tablename__ = "tickets"
    __table_args__ = (
        CheckConstraint(
            "priority IN ('low', 'normal', 'high', 'urgent')",
            name="ck_tickets_priority",
        ),
        CheckConstraint(
            "status IN ('new', 'open', 'pending', 'escalated', 'resolved', 'reopened', 'closed')",
            name="ck_tickets_status",
        ),
        Index("ix_tickets_status_priority", "status", "priority"),
        Index("ix_tickets_created_at", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(30), unique=True, nullable=False, index=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), nullable=False)
    channel_id: Mapped[int] = mapped_column(ForeignKey("channels.id"), nullable=False)
    intent_id: Mapped[int] = mapped_column(ForeignKey("intents.id"), nullable=False)
    language_id: Mapped[int] = mapped_column(ForeignKey("languages.id"), nullable=False)
    subject: Mapped[str] = mapped_column(String(240), nullable=False)
    priority: Mapped[str] = mapped_column(String(16), nullable=False, default="normal")
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="new", index=True)
    required_skill: Mapped[str] = mapped_column(String(60), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    due_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    customer_satisfaction: Mapped[float | None] = mapped_column(Float, nullable=True)

    customer: Mapped["Customer"] = relationship(back_populates="tickets")
    channel: Mapped["Channel"] = relationship(back_populates="tickets")
    intent: Mapped["Intent"] = relationship(back_populates="tickets")
    language: Mapped["Language"] = relationship(back_populates="tickets")
    messages: Mapped[list["Message"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan", order_by="Message.created_at"
    )
    assignment_events: Mapped[list["AssignmentEvent"]] = relationship(
        back_populates="ticket",
        cascade="all, delete-orphan",
        order_by="AssignmentEvent.created_at",
    )
    sla_events: Mapped[list["SLAEvent"]] = relationship(
        back_populates="ticket", cascade="all, delete-orphan", order_by="SLAEvent.created_at"
    )
    resolutions: Mapped[list["Resolution"]] = relationship(
        back_populates="ticket",
        order_by="Resolution.id",
        cascade="all, delete-orphan",
    )

    @property
    def resolution(self) -> "Resolution | None":
        """Return the latest resolution while retaining earlier resolution records."""
        return self.resolutions[-1] if self.resolutions else None


class Message(Base):
    __tablename__ = "messages"
    __table_args__ = (Index("ix_messages_ticket_created", "ticket_id", "created_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("tickets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    parent_message_id: Mapped[int | None] = mapped_column(
        ForeignKey("messages.id", ondelete="SET NULL"), nullable=True
    )
    sender_type: Mapped[str] = mapped_column(String(20), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    ticket: Mapped["Ticket"] = relationship(back_populates="messages")
    parent: Mapped["Message | None"] = relationship(
        remote_side="Message.id", back_populates="replies"
    )
    replies: Mapped[list["Message"]] = relationship(back_populates="parent")


class AssignmentEvent(Base):
    __tablename__ = "assignment_events"
    __table_args__ = (
        Index("ix_assignment_ticket_created", "ticket_id", "created_at"),
        Index("ix_assignment_agent_created", "agent_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("tickets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    agent_id: Mapped[int | None] = mapped_column(ForeignKey("agents.id"), nullable=True)
    source_agent_id: Mapped[int | None] = mapped_column(ForeignKey("agents.id"), nullable=True)
    queue_name: Mapped[str] = mapped_column(String(60), nullable=False)
    event_type: Mapped[str] = mapped_column(String(24), nullable=False, default="assigned")
    routing_score: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    reason: Mapped[str] = mapped_column(Text, nullable=False)
    decision_metadata: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)

    ticket: Mapped["Ticket"] = relationship(back_populates="assignment_events")
    agent: Mapped["Agent"] = relationship(
        back_populates="assignments", foreign_keys=[agent_id]
    )
    source_agent: Mapped["Agent | None"] = relationship(
        back_populates="source_assignments", foreign_keys=[source_agent_id]
    )


class SLAEvent(Base):
    __tablename__ = "sla_events"
    __table_args__ = (
        Index("ix_sla_ticket_created", "ticket_id", "created_at"),
        Index("ix_sla_type_created", "event_type", "created_at"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("tickets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    event_type: Mapped[str] = mapped_column(String(24), nullable=False)
    due_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    elapsed_business_minutes: Mapped[float | None] = mapped_column(Float, nullable=True)
    details: Mapped[str] = mapped_column(Text, nullable=False, default="")

    ticket: Mapped["Ticket"] = relationship(back_populates="sla_events")


class Resolution(Base):
    __tablename__ = "resolutions"
    __table_args__ = (Index("ix_resolution_ticket_resolved", "ticket_id", "resolved_at"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    ticket_id: Mapped[int] = mapped_column(
        ForeignKey("tickets.id", ondelete="CASCADE"), nullable=False, index=True
    )
    summary: Mapped[str] = mapped_column(Text, nullable=False)
    resolution_code: Mapped[str] = mapped_column(String(40), nullable=False)
    resolved_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    customer_satisfaction: Mapped[float | None] = mapped_column(Float, nullable=True)

    ticket: Mapped["Ticket"] = relationship(back_populates="resolutions")


@sqlalchemy_event.listens_for(Session, "before_flush")
def _reject_public_id_mutation(session, _flush_context, _instances):
    """Public IDs are stable after insertion; changing one breaks external references."""
    immutable_types = (Ticket, Message, Agent, AssignmentEvent, SLAEvent)
    for instance in session.dirty:
        if isinstance(instance, immutable_types):
            state = sqlalchemy_inspect(instance)
            if state.persistent and state.attrs.public_id.history.has_changes():
                raise ValueError(
                    f"{type(instance).__name__}.public_id is immutable after insertion"
                )
