"""Reproducible, chunked CSV/JSON/SQL exports for Tixora Route."""

import hashlib
import json
from datetime import date, datetime, timezone
from pathlib import Path

import pandas as pd
from sqlalchemy import func, insert, select
from sqlalchemy import create_engine
from sqlalchemy.orm import selectinload
from sqlalchemy.schema import CreateIndex, CreateTable

from .database import Base
from .models import Agent, AssignmentEvent, Message, Queue, Ticket


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_value(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def _row_dict(row: dict, table_name: str, public_ids: dict[str, dict[int, str]]) -> dict:
    result = {key: _json_value(value) for key, value in row.items()}
    ticket_ids = public_ids["tickets"]
    if "ticket_id" in result:
        result["ticket_public_id"] = ticket_ids.get(result["ticket_id"])
    if table_name == "messages" and result.get("parent_message_id") is not None:
        result["parent_message_public_id"] = public_ids["messages"].get(
            result["parent_message_id"]
        )
    if table_name == "assignment_events":
        result["agent_public_id"] = public_ids["agents"].get(result.get("agent_id"))
        result["source_agent_public_id"] = public_ids["agents"].get(
            result.get("source_agent_id")
        )
    return result


def _table_rows(db, table, chunk_size: int, public_ids: dict[str, dict[int, str]]):
    primary_keys = list(table.primary_key.columns)
    stmt = select(table).order_by(*primary_keys)
    count = db.scalar(select(func.count()).select_from(table)) or 0
    for offset in range(0, count, chunk_size):
        rows = db.execute(stmt.offset(offset).limit(chunk_size)).mappings()
        yield [
            _row_dict(dict(row), table.name, public_ids)
            for row in rows
        ]


def _public_id_maps(db) -> dict[str, dict[int, str]]:
    return {
        "tickets": dict(db.execute(select(Ticket.id, Ticket.public_id)).all()),
        "agents": dict(db.execute(select(Agent.id, Agent.public_id)).all()),
        "messages": dict(db.execute(select(Message.id, Message.public_id)).all()),
    }


def _expected_ground_truth(db) -> list[dict]:
    from .priority import enforce_priority
    from .validation import detect_anomalies

    tickets = list(db.scalars(
        select(Ticket)
        .options(
            selectinload(Ticket.intent),
            selectinload(Ticket.channel),
            selectinload(Ticket.language),
            selectinload(Ticket.assignment_events),
        )
        .order_by(Ticket.id)
    ))
    queue_by_intent = {
        queue.intent_name: queue.name for queue in db.scalars(select(Queue))
    }

    agents = list(db.scalars(
        select(Agent)
        .options(selectinload(Agent.skills))
        .order_by(Agent.public_id)
    ))
    current_load = {agent.id: 0 for agent in agents}
    agent_skills = {
        agent.id: {skill.name for skill in agent.skills} for agent in agents
    }
    expected_routes = {}
    priority_rank = {"low": 1, "normal": 2, "high": 3, "urgent": 4}
    channel_bonus = {"phone": 15, "chat": 10, "email": 5}
    for ticket in tickets:
        hour = ticket.created_at.hour
        eligible = []
        for agent in agents:
            if not agent.active:
                continue
            if ticket.required_skill not in agent_skills[agent.id]:
                continue
            if agent.language_code != ticket.language.code:
                continue
            if not agent.shift_start <= hour < agent.shift_end:
                continue
            if current_load[agent.id] >= agent.capacity:
                continue
            score = (
                priority_rank.get(ticket.priority, 0) * 100
                + channel_bonus.get(ticket.channel.name, 0)
                - current_load[agent.id] * 10
            )
            eligible.append((agent, score))

        eligible.sort(
            key=lambda item: (-item[1], current_load[item[0].id], item[0].public_id)
        )
        if eligible:
            selected, _score = eligible[0]
            expected_routes[ticket.id] = ("assigned", selected.public_id)
            current_load[selected.id] += 1
        else:
            expected_routes[ticket.id] = ("queued", None)

    labels_by_ticket: dict[str, set[str]] = {}
    agent_public_ids = {
        agent.public_id: agent.id for agent in db.scalars(select(Agent))
    }
    ticket_by_id = {ticket.id: ticket.public_id for ticket in tickets}
    for finding in detect_anomalies(db):
        entity = finding["entity"]
        if entity in ticket_by_id.values():
            labels_by_ticket.setdefault(entity, set()).add(finding["scenario"])
        elif entity in agent_public_ids:
            for event in db.scalars(
                select(AssignmentEvent.ticket_id).where(
                    AssignmentEvent.agent_id == agent_public_ids[entity]
                )
            ):
                ticket_public_id = ticket_by_id.get(event)
                if ticket_public_id:
                    labels_by_ticket.setdefault(ticket_public_id, set()).add(
                        finding["scenario"]
                    )

    records = []
    for ticket in tickets:
        expected_decision, expected_agent = expected_routes[ticket.id]
        actual_event = max(
            ticket.assignment_events,
            key=lambda event: (event.id or 0),
            default=None,
        )
        observed_decision = (
            "assigned"
            if actual_event and actual_event.event_type in {"assigned", "transferred"}
            else "queued"
            if actual_event and actual_event.event_type == "queued"
            else "not_routed"
        )
        expected_priority, _reason = enforce_priority(ticket.intent.name, ticket.priority)
        records.append({
            "ticket_id": ticket.public_id,
            "expected_decision": expected_decision,
            "expected_agent": expected_agent,
            "observed_decision": observed_decision,
            "expected_priority": expected_priority,
            "observed_priority": ticket.priority,
            "expected_skill": ticket.intent.required_skill,
            "expected_queue": queue_by_intent.get(ticket.intent.name, "general"),
            "anomaly_labels": sorted(labels_by_ticket.get(ticket.public_id, set())),
            "label_source": "business_rules",
        })
    return records


def export_all(
    db,
    out_dir: str = "exports",
    chunk_size: int = 5000,
    seed: int = 20261022,
) -> dict:
    """Write all model and bridge tables to CSV and JSON with a checksum manifest."""
    if chunk_size < 1:
        raise ValueError("chunk_size must be positive")

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    public_ids = _public_id_maps(db)
    checksums: dict[str, str] = {}
    row_counts: dict[str, int] = {}

    for table in Base.metadata.sorted_tables:
        table_name = table.name
        csv_path = out / f"{table_name}.csv"
        json_path = out / f"{table_name}.json"
        columns = [column.name for column in table.columns]
        extra_columns = []
        if "ticket_id" in columns:
            extra_columns.append("ticket_public_id")
        if table_name == "messages":
            extra_columns.append("parent_message_public_id")
        if table_name == "assignment_events":
            extra_columns.extend(("agent_public_id", "source_agent_public_id"))
        csv_columns = columns + extra_columns
        row_count = db.scalar(select(func.count()).select_from(table)) or 0
        row_counts[table_name] = row_count

        with csv_path.open("w", encoding="utf-8-sig", newline="") as csv_file, \
                json_path.open("w", encoding="utf-8") as json_file:
            csv_file.write("")
            json_file.write("[")
            first_json = True
            first_csv_chunk = True
            for rows in _table_rows(db, table, chunk_size, public_ids):
                dataframe = pd.DataFrame(rows, columns=csv_columns)
                dataframe.to_csv(
                    csv_file,
                    index=False,
                    header=first_csv_chunk,
                    columns=csv_columns,
                )
                first_csv_chunk = False
                for row in rows:
                    if not first_json:
                        json_file.write(",")
                    json.dump(row, json_file, ensure_ascii=False, separators=(",", ":"))
                    first_json = False
            if first_csv_chunk:
                pd.DataFrame(columns=csv_columns).to_csv(csv_file, index=False)
            json_file.write("]\n")

        checksums[csv_path.name] = _sha256(csv_path)
        checksums[json_path.name] = _sha256(json_path)

    ground_truth = _expected_ground_truth(db)
    truth_json = out / "ground_truth.json"
    truth_csv = out / "ground_truth.csv"
    truth_json.write_text(json.dumps(ground_truth, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(ground_truth).to_csv(truth_csv, index=False, encoding="utf-8-sig")
    checksums[truth_json.name] = _sha256(truth_json)
    checksums[truth_csv.name] = _sha256(truth_csv)

    from .metrics import get_metrics
    from .validation import validate

    metrics_path = out / "metrics.json"
    validation_path = out / "validation_summary.json"
    row_counts_path = out / "row_counts.json"
    metrics_path.write_text(json.dumps(get_metrics(db), indent=2, sort_keys=True), encoding="utf-8")
    validation_path.write_text(
        json.dumps(validate(db), default=str, indent=2, sort_keys=True), encoding="utf-8"
    )
    row_counts_path.write_text(
        json.dumps(row_counts, indent=2, sort_keys=True), encoding="utf-8"
    )
    for path in (metrics_path, validation_path, row_counts_path):
        checksums[path.name] = _sha256(path)

    sql_path = out / "tixora_route.sql"
    export_sql(db, sql_path)
    checksums[sql_path.name] = _sha256(sql_path)

    manifest_path = out / "source_manifest.json"
    manifest = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "algorithm": "sha256",
        "seed": seed,
        "provenance": (
            "Deterministic synthetic records generated from the documented seed and "
            "business rules. No real personal data or third-party records are used."
        ),
        "row_counts": row_counts,
        "files": checksums,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8")

    return {
        "directory": str(out),
        "files": list(checksums),
        "checksums": checksums,
        "row_counts": row_counts,
    }


def export_sql(db, path: str | Path = "exports/tixora_route.sql") -> str:
    """Export executable table DDL and deterministic INSERT seed statements."""
    from sqlalchemy.schema import CreateTable

    bind = db.get_bind()
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    lines = ["-- Tixora Route SQLite schema and synthetic seed data", ""]
    for table in Base.metadata.sorted_tables:
        lines.append(str(CreateTable(table).compile(dialect=bind.dialect)) + ";")
        for index in sorted(table.indexes, key=lambda item: item.name or ""):
            lines.append(str(CreateIndex(index).compile(dialect=bind.dialect)) + ";")
    lines.append("")

    for table in Base.metadata.sorted_tables:
        rows = db.execute(select(table).order_by(*table.primary_key.columns)).mappings()
        for row in rows:
            statement = insert(table).values(**dict(row)).compile(
                dialect=bind.dialect,
                compile_kwargs={"literal_binds": True},
            )
            lines.append(str(statement) + ";")
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return str(destination)


def export_schema(path: str | Path = "schema.sql") -> str:
    """Write a schema-only SQL snapshot from the current SQLAlchemy metadata."""
    dialect_engine = create_engine("sqlite://")
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    lines = ["-- Tixora Route schema; generated from src/tixora_route/models.py", ""]
    for table in Base.metadata.sorted_tables:
        lines.append(str(CreateTable(table).compile(dialect=dialect_engine.dialect)) + ";")
        for index in sorted(table.indexes, key=lambda item: item.name or ""):
            lines.append(str(CreateIndex(index).compile(dialect=dialect_engine.dialect)) + ";")
    destination.write_text("\n".join(lines) + "\n", encoding="utf-8")
    dialect_engine.dispose()
    return str(destination)


def export_reproducibility_report(out_dir: str = "exports") -> dict:
    """Verify exported checksums against the source manifest."""
    out = Path(out_dir)
    manifest_path = out / "source_manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"Source manifest not found: {manifest_path}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    results = {}
    for filename, expected in manifest.get("files", {}).items():
        path = out / filename
        if not path.is_file():
            results[filename] = {"match": False, "error": "file not found"}
            continue
        actual = _sha256(path)
        results[filename] = {
            "expected_sha256": expected,
            "actual_sha256": actual,
            "match": expected == actual,
            "size_bytes": path.stat().st_size,
        }
    return {
        "file_count": len(results),
        "files": results,
        "all_match": bool(results) and all(item["match"] for item in results.values()),
        "row_counts": manifest.get("row_counts", {}),
    }
