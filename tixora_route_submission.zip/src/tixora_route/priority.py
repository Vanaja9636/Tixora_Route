"""Priority enforcement rules for Tixora Route."""
from .enums import PRIORITY_RANK


def enforce_priority(intent_name: str, priority: str) -> tuple[str, str]:
    """
    Enforce documented business priority rules.

    Rule PR-001 (Safety Rule): Any ticket with intent 'safety' MUST be
    assigned priority 'urgent'. This is a hard safety constraint.

    Returns:
        (effective_priority, reason_message)
    """
    if intent_name == "safety" and PRIORITY_RANK.get(priority, 0) < 4:
        return "urgent", f"Safety intent requires urgent priority (PR-001). Requested={priority!r} overridden."
    return priority, "Priority accepted as-is."


def priority_score(priority: str) -> int:
    """Return numeric priority score for comparison."""
    return PRIORITY_RANK.get(priority, 0)
