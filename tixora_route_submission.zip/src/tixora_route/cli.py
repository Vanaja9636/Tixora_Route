"""
CLI for Tixora Route.

Commands:
  init       - Initialize the SQLite database
  generate   - Generate synthetic data
  demo       - Quick 100-ticket demo with seed 20261022
  simulate   - Route all unassigned tickets
  validate   - Run validation suite
  anomalies  - Detect the five anomaly classes
  export     - Export CSV, JSON, and SQL
  metrics    - Print platform metrics
  repro      - Verify reproducibility (generate twice, compare checksums)
  all        - Run complete workflow: generate + simulate + validate + export + metrics

Usage examples:
  python -m tixora_route.cli demo
  python -m tixora_route.cli all --tickets 100 --agents 100 --messages 300
  python -m tixora_route.cli all --tickets 30000 --agents 100 --messages 100000
  python -m tixora_route.cli validate
  python -m tixora_route.cli anomalies
  python -m tixora_route.cli repro
"""
import argparse
import json
import sys
from pathlib import Path
from sqlalchemy.orm import sessionmaker

from .config import load_config, database_url
from .database import make_engine, init_db
from .generator import generate
from .simulation import simulate
from .validation import validate, detect_anomalies
from .metrics import get_metrics
from .exports import export_all, export_sql, export_reproducibility_report


def _make_session(db_url=None):
    cfg = load_config()
    url = db_url or database_url(cfg)
    eng = make_engine(url)
    init_db(eng)
    Session = sessionmaker(bind=eng, expire_on_commit=False)
    return Session(), cfg


def _json(obj):
    print(json.dumps(obj, default=str, indent=2))


def cmd_init(args):
    db, cfg = _make_session(args.database)
    try:
        _json({"status": "database_initialized", "url": args.database or database_url(cfg)})
    finally:
        db.close()


def cmd_demo(args):
    """Quick 100-ticket demo."""
    db, cfg = _make_session(args.database)
    try:
        gen = generate(db, tickets=100, messages=300, seed=20261022, agent_count=100, event_days=90)
        sim = simulate(db, include_decisions=False)
        val = validate(db)
        mtr = get_metrics(db)
        exp = export_all(db, args.out, seed=20261022)
        exp["sql"] = str(Path(args.out) / "tixora_route.sql")
        _json({
            "demo": "100-ticket quick demo",
            "seed": 20261022,
            "generation": gen,
            "simulation": {k: sim[k] for k in ("processed", "assigned", "queued")},
            "validation": {"valid": val["valid"], "issue_count": val["issue_count"]},
            "metrics": mtr,
            "exports": {"directory": exp["directory"], "files": exp["files"]},
        })
        if not val["valid"]:
            raise SystemExit(1)
    finally:
        db.close()


def cmd_generate(args):
    db, cfg = _make_session(args.database)
    try:
        gen_cfg = cfg.get("generation", {})
        result = generate(
            db,
            tickets=args.tickets if args.tickets is not None else gen_cfg.get("tickets", 100),
            messages=args.messages if args.messages is not None else gen_cfg.get("messages", 300),
            seed=args.seed if args.seed is not None else cfg["app"].get("seed", 20261022),
            agent_count=args.agents if args.agents is not None else gen_cfg.get("agents", 100),
            event_days=args.event_days if args.event_days is not None else gen_cfg.get("event_days", 90),
        )
        _json(result)
    finally:
        db.close()


def cmd_simulate(args):
    db, _ = _make_session(args.database)
    try:
        result = simulate(db, args.limit, include_decisions=False)
        _json({k: result[k] for k in ("processed", "assigned", "queued")})
    finally:
        db.close()


def cmd_validate(args):
    db, _ = _make_session(args.database)
    try:
        result = validate(db)
        _json(result)
        if not result["valid"]:
            raise SystemExit(1)
    finally:
        db.close()


def cmd_anomalies(args):
    db, _ = _make_session(args.database)
    try:
        found = detect_anomalies(db)
        _json({"anomalies_detected": len(found), "anomalies": found})
    finally:
        db.close()


def cmd_export(args):
    db, _ = _make_session(args.database)
    try:
        result = export_all(
            db,
            args.out,
            seed=args.seed if args.seed is not None else 20261022,
        )
        result["sql"] = export_sql(db, str(Path(args.out) / "tixora_route.sql"))
        _json(result)
    finally:
        db.close()


def cmd_metrics(args):
    db, _ = _make_session(args.database)
    try:
        _json(get_metrics(db))
    finally:
        db.close()


def cmd_repro(args):
    """
    Reproducibility check: generate the same dataset twice, compare checksums.
    Uses a fresh in-memory database each time to ensure independence.
    """
    import tempfile
    import os

    results = []
    for run in range(1, 3):
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            tmp_db_path = f.name

        try:
            url = f"sqlite:///{tmp_db_path}"
            eng = make_engine(url)
            init_db(eng)
            Session = sessionmaker(bind=eng, expire_on_commit=False)
            db = Session()

            generate(
                db,
                tickets=args.tickets if args.tickets is not None else 100,
                messages=args.messages if args.messages is not None else 300,
                seed=args.seed if args.seed is not None else 20261022,
                agent_count=args.agents if args.agents is not None else 20,
                event_days=args.event_days if args.event_days is not None else 30,
            )

            with tempfile.TemporaryDirectory() as tmp_out:
                exp = export_all(
                    db,
                    tmp_out,
                    seed=args.seed if args.seed is not None else 20261022,
                )
                results.append({
                    "run": run,
                    "checksums": exp["checksums"],
                    "files": exp["files"],
                })
            db.close()
            eng.dispose()
        finally:
            try:
                os.unlink(tmp_db_path)
            except FileNotFoundError:
                pass

    # Compare checksums
    if len(results) == 2:
        r1, r2 = results
        matching = {
            f: r1["checksums"].get(f) == r2["checksums"].get(f)
            for f in r1["checksums"]
        }
        all_match = all(matching.values())
        _json({
            "reproducibility": "PASS" if all_match else "FAIL",
            "seed": args.seed if args.seed is not None else 20261022,
            "run_1_checksums": r1["checksums"],
            "run_2_checksums": r2["checksums"],
            "matches_per_file": matching,
        })
        if not all_match:
            raise SystemExit(1)
    else:
        _json({"error": "Could not complete both runs"})


def cmd_all(args):
    db, cfg = _make_session(args.database)
    try:
        gen_cfg = cfg.get("generation", {})
        seed = args.seed if args.seed is not None else cfg["app"].get("seed", 20261022)
        gen = generate(
            db,
            tickets=args.tickets if args.tickets is not None else gen_cfg.get("tickets", 100),
            messages=args.messages if args.messages is not None else gen_cfg.get("messages", 300),
            seed=seed,
            agent_count=args.agents if args.agents is not None else gen_cfg.get("agents", 100),
            event_days=args.event_days if args.event_days is not None else gen_cfg.get("event_days", 90),
        )
        sim = simulate(db, args.limit, include_decisions=False)
        val = validate(db)
        mtr = get_metrics(db)
        exp = export_all(db, args.out, seed=seed)
        exp["sql"] = str(Path(args.out) / "tixora_route.sql")
        _json({
            "generation": gen,
            "simulation": {k: sim[k] for k in ("processed", "assigned", "queued")},
            "validation": val,
            "metrics": mtr,
            "exports": exp,
        })
        if not val["valid"]:
            raise SystemExit(1)
    finally:
        db.close()


def main():
    parser = argparse.ArgumentParser(
        prog="tixora_route",
        description="Tixora Route — Intelligent Ticket Routing and SLA Management CLI",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # Shared arguments
    def add_common(p):
        p.add_argument("--database", help="SQLite DB URL (overrides config.yaml)")
        p.add_argument("--out", default="exports", help="Export output directory")
        p.add_argument("--tickets", type=int, help="Number of tickets")
        p.add_argument("--agents", type=int, help="Number of agents")
        p.add_argument("--messages", type=int, help="Number of messages")
        p.add_argument("--seed", type=int, help="RNG seed (default: 20261022)")
        p.add_argument("--event-days", type=int, dest="event_days", help="Simulation span in days")
        p.add_argument("--limit", type=int, help="Limit for simulate command")

    sub_init = sub.add_parser("init", help="Initialize the database")
    add_common(sub_init)

    sub_demo = sub.add_parser("demo", help="Quick 100-ticket demo with seed 20261022")
    add_common(sub_demo)

    sub_gen = sub.add_parser("generate", help="Generate synthetic data")
    add_common(sub_gen)

    sub_sim = sub.add_parser("simulate", help="Route all unassigned tickets")
    add_common(sub_sim)

    sub_val = sub.add_parser("validate", help="Run validation suite")
    add_common(sub_val)

    sub_ano = sub.add_parser("anomalies", help="Detect the five anomaly classes")
    add_common(sub_ano)

    sub_exp = sub.add_parser("export", help="Export CSV, JSON, SQL")
    add_common(sub_exp)

    sub_mtr = sub.add_parser("metrics", help="Print platform metrics")
    add_common(sub_mtr)

    sub_repro = sub.add_parser("repro", help="Verify reproducibility (2 runs, compare checksums)")
    add_common(sub_repro)

    sub_all = sub.add_parser("all", help="Run complete workflow")
    add_common(sub_all)

    args = parser.parse_args()

    dispatch = {
        "init": cmd_init,
        "demo": cmd_demo,
        "generate": cmd_generate,
        "simulate": cmd_simulate,
        "validate": cmd_validate,
        "anomalies": cmd_anomalies,
        "export": cmd_export,
        "metrics": cmd_metrics,
        "repro": cmd_repro,
        "all": cmd_all,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
