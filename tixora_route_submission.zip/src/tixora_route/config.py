from pathlib import Path
import yaml
ROOT=Path(__file__).resolve().parents[2]
def load_config(path=None):
    with (Path(path) if path else ROOT/"config.yaml").open(encoding="utf-8") as f: return yaml.safe_load(f)
def database_url(config=None):
    url=(config or load_config())["app"]["database_url"]
    if url.startswith("sqlite:///"):
        p=Path(url[10:])
        if not p.is_absolute(): p=ROOT/p
        p.parent.mkdir(parents=True,exist_ok=True)
        return "sqlite:///"+str(p)
    return url
