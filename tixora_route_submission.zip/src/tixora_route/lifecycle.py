"""
Ticket lifecycle management for Tixora Route.

Implements: resolve, reopen, escalate, transfer, close.
All state transitions are immutably recorded as SLAEvents.
History is never overwritten.

Lifecycle states and valid transitions:
  new -> open, pending, closed
  open -> pending, resolved, escalated, closed
  pending -> open, resolved, escalated, closed
  escalated -> open, resolved, closed
  resolved -> reopened, closed
  reopened -> open, pending, resolved, closed
  closed -> reopened
"""
from datetime import datetime, timezone
from .models import Resolution, SLAEvent, AssignmentEvent
from .calendar import elapsed_business_minutes
from .enums import VALID_TRANSITIONS


def _now(at=None) -> datetime:
    return at or datetime.now(timezone.utc).replace(tzinfo=None)


def _next_sla_id(ticket, suffix: str) -> str:
    base = f"SLA-{ticket.public_id}-{suffix}"
    existing = {event.public_id for event in ticket.sla_events}
    if base not in existing:
        return base
    sequence = 2
    while f"{base}-{sequence:03}" in existing:
        sequence += 1
    return f"{base}-{sequence:03}"


def _validate_transition(ticket, target: str) -> None:
    if target not in VALID_TRANSITIONS.get(ticket.status, set()):
        raise ValueError(f"Invalid ticket lifecycle transition: {ticket.status} -> {target}")


def resolve_ticket(
    db,
    ticket,
    summary: str = "Issue resolved",
    code: str = "resolved",
    satisfaction: float = 5.0,
    at: datetime | None = None,
) -> None:
    """
    Mark a ticket as resolved. Records Resolution and SLAEvent.
    Does NOT overwrite existing history.
    """
    _validate_transition(ticket, "resolved")
    if satisfaction is not None and not 1 <= satisfaction <= 5:
        raise ValueError("customer satisfaction must be between 1 and 5")
    now = _now(at)
    if now < ticket.created_at:
        raise ValueError("resolution time cannot precede ticket creation")
    ticket.status = "resolved"
    ticket.resolved_at = now
    ticket.customer_satisfaction = satisfaction

    db.add(Resolution(
        ticket=ticket,
        summary=summary,
        resolution_code=code,
        resolved_at=now,
        customer_satisfaction=satisfaction,
    ))
    db.add(SLAEvent(
        public_id=_next_sla_id(ticket, "RES"),
        ticket=ticket,
        event_type="resolved",
        due_at=ticket.due_at,
        created_at=now,
        elapsed_business_minutes=elapsed_business_minutes(
            ticket.created_at, now, ticket.channel.calendar_type
        ),
        details=f"Ticket resolved; code={code}; satisfaction={satisfaction}",
    ))


def reopen_ticket(db, ticket, reason: str = "Customer requested reopen", at: datetime | None = None) -> None:
    """
    Reopen a resolved/closed ticket. Records a reopening SLAEvent.
    History is preserved — does not delete any existing events.
    """
    _validate_transition(ticket, "reopened")
    now = _now(at)
    if now < ticket.created_at:
        raise ValueError("reopen time cannot precede ticket creation")
    ticket.status = "reopened"
    ticket.resolved_at = None

    db.add(SLAEvent(
        public_id=_next_sla_id(ticket, "REOPEN"),
        ticket=ticket,
        event_type="reopened",
        due_at=ticket.due_at,
        created_at=now,
        details=f"Reopen history preserved; reason={reason}",
    ))


def escalate_ticket(db, ticket, reason: str = "SLA breach imminent", at: datetime | None = None) -> None:
    """Escalate a ticket. Records escalation in SLAEvent."""
    _validate_transition(ticket, "escalated")
    now = _now(at)
    if now < ticket.created_at:
        raise ValueError("escalation time cannot precede ticket creation")
    ticket.status = "escalated"

    db.add(SLAEvent(
        public_id=_next_sla_id(ticket, "ESC"),
        ticket=ticket,
        event_type="escalated",
        due_at=ticket.due_at,
        created_at=now,
        details=f"Escalated; reason={reason}",
    ))


def transfer_ticket(db, ticket, from_agent, to_agent, reason: str = "Transfer", at: datetime | None = None) -> None:
    """
    Transfer a ticket between agents. Records AssignmentEvent with
    event_type='transferred'. Does not overwrite history.

    Transfer-loop detection: if the same two agents have 3+ transfers
    back and forth, it is flagged as an anomaly by the detector.
    """
    now = _now(at)
    if now < ticket.created_at:
        raise ValueError("transfer time cannot precede ticket creation")
    n = len(ticket.assignment_events) + 1

    db.add(AssignmentEvent(
        public_id=f"ASN-{ticket.public_id}-{n:03}",
        ticket=ticket,
        agent_id=to_agent.id,
        source_agent_id=from_agent.id,
        queue_name="transfer",
        event_type="transferred",
        reason=f"Transferred from {from_agent.public_id} to {to_agent.public_id}; {reason}",
        created_at=now,
    ))


def close_ticket(db, ticket, at: datetime | None = None) -> None:
    """Close a ticket (terminal state)."""
    _validate_transition(ticket, "closed")
    now = _now(at)
    ticket.status = "closed"

    db.add(SLAEvent(
        public_id=_next_sla_id(ticket, "CLOSE"),
        ticket=ticket,
        event_type="closed",
        due_at=ticket.due_at,
        created_at=now,
        details="Ticket closed",
    ))
