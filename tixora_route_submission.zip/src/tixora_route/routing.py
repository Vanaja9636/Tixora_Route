"""
Explainable ticket routing engine for Tixora Route.

Routing algorithm:
1. Determine the target queue from the ticket's intent.
2. Compute current agent load (active open/pending/reopened assignments).
3. Filter candidates: skill match → language match → shift availability → capacity.
4. Score candidates by (load_asc, public_id_asc) for determinism.
5. Assign to lowest-load eligible agent; record AssignmentEvent with full explanation.
6. If no eligible agent, route to queue and record 'queued' decision.

Rules enforced (NEVER violated in normal routing):
  RR-001: Agent must have the required skill.
  RR-002: Agent language must match ticket language.
  RR-003: Ticket creation hour must fall within agent shift window.
  RR-004: Agent current load must be strictly below capacity.
"""
import json

from sqlalchemy import select
from sqlalchemy.orm import selectinload
from .models import Agent, Ticket, AssignmentEvent, Queue
from .enums import PRIORITY_RANK


CHANNEL_BONUS = {"phone": 15, "chat": 10, "email": 5}


def _agent_load(db) -> dict[int, int]:
    """Count each active ticket only against its latest non-queued assignment."""
    active_statuses = ("open", "pending", "reopened", "escalated")
    rows = db.execute(
        select(
            AssignmentEvent.ticket_id,
            AssignmentEvent.agent_id,
            AssignmentEvent.event_type,
        )
        .join(Ticket, Ticket.id == AssignmentEvent.ticket_id)
        .where(
            AssignmentEvent.event_type.in_(["assigned", "transferred", "queued"]),
            Ticket.status.in_(active_statuses),
        )
        .order_by(AssignmentEvent.id)
    ).all()
    latest_agent_by_ticket = {}
    for ticket_id, agent_id, event_type in rows:
        latest_agent_by_ticket[ticket_id] = (
            agent_id if event_type in {"assigned", "transferred"} else None
        )

    load: dict[int, int] = {}
    for agent_id in latest_agent_by_ticket.values():
        if agent_id is not None:
            load[agent_id] = load.get(agent_id, 0) + 1
    return load


def route_ticket(
    db,
    ticket,
    at=None,
    *,
    agents: list[Agent] | None = None,
    current_load: dict[int, int] | None = None,
    queue_by_intent: dict[str, str] | None = None,
) -> dict:
    """
    Route a single ticket to the best eligible agent.

    Returns a structured decision dict with:
      - ticket_id, assigned_agent, queue, decision
      - explanation (list of reason strings)
      - eligible_candidates count
      - rejected_candidates list with rejection reasons
    """
    if ticket.status not in {"new", "pending", "reopened"}:
        raise ValueError(
            f"Ticket {ticket.public_id} in state {ticket.status!r} cannot be routed"
        )

    # Identify queue
    if queue_by_intent is None:
        queue = db.scalar(select(Queue).where(Queue.intent_name == ticket.intent.name))
        qname = queue.name if queue else "general"
    else:
        qname = queue_by_intent.get(ticket.intent.name, "general")

    load = current_load if current_load is not None else _agent_load(db)
    hour = (at or ticket.created_at).hour

    candidates = []
    rejected = []
    channel_bonus = CHANNEL_BONUS.get(ticket.channel.name, 0)
    priority_score = PRIORITY_RANK.get(ticket.priority, 0) * 100

    eligible_agents = agents
    if eligible_agents is None:
        eligible_agents = list(db.scalars(
            select(Agent)
            .options(selectinload(Agent.skills))
            .where(Agent.active.is_(True))
        ))
    for agent in eligible_agents:
        if not agent.active:
            continue
        agent_skills = {s.name for s in agent.skills}

        # RR-001: Skill check
        if ticket.required_skill not in agent_skills:
            rejected.append({
                "agent": agent.public_id,
                "reason": f"Missing skill '{ticket.required_skill}' (has: {sorted(agent_skills)})",
                "rule": "RR-001",
                "score": None,
            })
            continue

        # RR-002: Language check
        if agent.language_code != ticket.language.code:
            rejected.append({
                "agent": agent.public_id,
                "reason": f"Language mismatch: agent={agent.language_code!r}, ticket={ticket.language.code!r}",
                "rule": "RR-002",
                "score": None,
            })
            continue

        # RR-003: Shift availability
        if not (agent.shift_start <= hour < agent.shift_end):
            rejected.append({
                "agent": agent.public_id,
                "reason": f"Outside shift {agent.shift_start}–{agent.shift_end}, request hour={hour}",
                "rule": "RR-003",
                "score": None,
            })
            continue

        # RR-004: Capacity check
        agent_load = load.get(agent.id, 0)
        if agent_load >= agent.capacity:
            rejected.append({
                "agent": agent.public_id,
                "reason": f"At capacity ({agent_load}/{agent.capacity})",
                "rule": "RR-004",
                "score": None,
            })
            continue

        score = priority_score + channel_bonus - agent_load * 10
        candidates.append((agent, score))

    # Priority and channel urgency are scored first; load and public ID break ties.
    candidates.sort(
        key=lambda item: (-item[1], load.get(item[0].id, 0), item[0].public_id)
    )

    base_reasons = [
        f"intent={ticket.intent.name}",
        f"priority={ticket.priority}",
        f"language={ticket.language.code}",
        f"required_skill={ticket.required_skill}",
        f"channel={ticket.channel.name}",
        f"queue={qname}",
        f"request_hour={hour}",
        f"urgency={ticket.priority}",
    ]

    if not candidates:
        explanation = base_reasons + [
            "No agent met all constraints (skill/language/shift/capacity)"
        ]
        decision_metadata = {
            "channel": ticket.channel.name,
            "intent": ticket.intent.name,
            "priority": ticket.priority,
            "rejected_candidates": rejected,
        }
        n = len(ticket.assignment_events) + 1
        db.add(AssignmentEvent(
            public_id=f"ASN-{ticket.public_id}-{n:03}",
            ticket=ticket,
            agent_id=None,
            queue_name=qname,
            event_type="queued",
            routing_score=0.0,
            reason="; ".join(explanation),
            decision_metadata=json.dumps(decision_metadata, sort_keys=True),
            created_at=at or ticket.created_at,
        ))
        ticket.status = "pending"
        return {
            "ticket_id": ticket.public_id,
            "assigned_agent": None,
            "queue": qname,
            "explanation": explanation,
            "eligible_candidates": 0,
            "rejected_candidates": rejected,
            "decision": "queued",
        }

    agent, score = candidates[0]
    agent_load = load.get(agent.id, 0)
    explanation = base_reasons + [
        f"selected_agent={agent.public_id}",
        f"agent_load={agent_load}/{agent.capacity}",
        f"routing_score={score}",
        "selection_rule=priority_and_channel_score_then_lowest_load_then_stable_public_id",
        f"eligible_candidates={len(candidates)}",
    ]

    n = len(ticket.assignment_events) + 1
    decision_metadata = {
        "channel": ticket.channel.name,
        "intent": ticket.intent.name,
        "priority": ticket.priority,
        "rejected_candidates": rejected,
        "eligible_candidates": [
            {"agent": candidate.public_id, "score": candidate_score}
            for candidate, candidate_score in candidates
        ],
    }
    db.add(AssignmentEvent(
        public_id=f"ASN-{ticket.public_id}-{n:03}",
        ticket=ticket,
        agent_id=agent.id,
        queue_name=qname,
        event_type="assigned",
        routing_score=score,
        reason="; ".join(explanation),
        decision_metadata=json.dumps(decision_metadata, sort_keys=True),
        created_at=at or ticket.created_at,
    ))
    ticket.status = "open"
    if current_load is not None:
        current_load[agent.id] = current_load.get(agent.id, 0) + 1

    return {
        "ticket_id": ticket.public_id,
        "assigned_agent": agent.public_id,
        "queue": qname,
        "explanation": explanation,
        "eligible_candidates": len(candidates),
        "rejected_candidates": rejected,
        "decision": "assigned",
    }
