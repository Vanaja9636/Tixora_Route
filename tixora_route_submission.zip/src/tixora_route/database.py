from sqlalchemy import create_engine,event,inspect
from sqlalchemy.orm import DeclarativeBase,sessionmaker
from .config import database_url
class Base(DeclarativeBase): pass
def make_engine(url=None):
    url=url or database_url()
    eng=create_engine(url,future=True,connect_args={"check_same_thread":False} if url.startswith("sqlite") else {})
    if eng.dialect.name=="sqlite":
        @event.listens_for(eng,"connect")
        def fk(conn,rec):
            cur=conn.cursor(); cur.execute("PRAGMA foreign_keys=ON"); cur.execute("PRAGMA journal_mode=WAL"); cur.close()
    return eng
engine=make_engine()
SessionLocal=sessionmaker(bind=engine,autoflush=False,expire_on_commit=False)
def init_db(target_engine=None):
    from . import models
    target = target_engine or engine
    Base.metadata.create_all(target)
    if target.dialect.name == "sqlite":
        _upgrade_sqlite_schema(target)


def _upgrade_sqlite_schema(target_engine):
    """Apply additive SQLite upgrades while preserving rows from earlier runs."""
    with target_engine.begin() as connection:
        tables = set(inspect(connection).get_table_names())

        if "assignment_events" in tables:
            columns = {
                column["name"]: column
                for column in inspect(connection).get_columns("assignment_events")
            }
            if columns.get("agent_id", {}).get("nullable") is False:
                connection.exec_driver_sql(
                    """
                    CREATE TABLE assignment_events_new (
                        id INTEGER NOT NULL PRIMARY KEY,
                        public_id VARCHAR(64) NOT NULL UNIQUE,
                        ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
                        agent_id INTEGER REFERENCES agents(id),
                        source_agent_id INTEGER REFERENCES agents(id),
                        queue_name VARCHAR(60) NOT NULL,
                        event_type VARCHAR(24) NOT NULL,
                        routing_score FLOAT NOT NULL DEFAULT 0,
                        reason TEXT NOT NULL,
                        decision_metadata TEXT NOT NULL DEFAULT '{}',
                        created_at DATETIME NOT NULL
                    )
                    """
                )
                connection.exec_driver_sql(
                    """
                    INSERT INTO assignment_events_new
                    (id, public_id, ticket_id, agent_id, queue_name, event_type, reason, created_at)
                    SELECT id, public_id, ticket_id, agent_id, queue_name, event_type, reason, created_at
                    FROM assignment_events
                    """
                )
                connection.exec_driver_sql("DROP TABLE assignment_events")
                connection.exec_driver_sql(
                    "ALTER TABLE assignment_events_new RENAME TO assignment_events"
                )

        tables = set(inspect(connection).get_table_names())
        additive_columns = {
            "messages": {
                "parent_message_id": "INTEGER REFERENCES messages(id) ON DELETE SET NULL",
            },
            "assignment_events": {
                "source_agent_id": "INTEGER REFERENCES agents(id)",
                "routing_score": "FLOAT NOT NULL DEFAULT 0",
                "decision_metadata": "TEXT NOT NULL DEFAULT '{}'",
            },
            "sla_events": {
                "elapsed_business_minutes": "FLOAT",
            },
            "priority_rules": {
                "effective_from": "DATETIME",
                "effective_to": "DATETIME",
            },
        }
        for table_name, definitions in additive_columns.items():
            if table_name not in tables:
                continue
            existing = {
                column["name"]
                for column in inspect(connection).get_columns(table_name)
            }
            for name, definition in definitions.items():
                if name not in existing:
                    connection.exec_driver_sql(
                        f"ALTER TABLE {table_name} ADD COLUMN {name} {definition}"
                    )

        if "priority_rules" in tables:
            connection.exec_driver_sql(
                "UPDATE priority_rules SET effective_from = '2026-01-01 09:00:00' "
                "WHERE effective_from IS NULL"
            )

        if "resolutions" in tables:
            unique_ticket_index = False
            resolution_inspector = inspect(connection)
            for index in resolution_inspector.get_indexes("resolutions"):
                if index.get("unique") and index.get("column_names") == ["ticket_id"]:
                    unique_ticket_index = True
                    break
            for constraint in resolution_inspector.get_unique_constraints("resolutions"):
                if constraint.get("column_names") == ["ticket_id"]:
                    unique_ticket_index = True
                    break
            if unique_ticket_index:
                connection.exec_driver_sql(
                    """
                    CREATE TABLE resolutions_new (
                        id INTEGER NOT NULL PRIMARY KEY,
                        ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
                        summary TEXT NOT NULL,
                        resolution_code VARCHAR(40) NOT NULL,
                        resolved_at DATETIME NOT NULL,
                        customer_satisfaction FLOAT
                    )
                    """
                )
                connection.exec_driver_sql(
                    """
                    INSERT INTO resolutions_new
                    (id, ticket_id, summary, resolution_code, resolved_at, customer_satisfaction)
                    SELECT id, ticket_id, summary, resolution_code, resolved_at, customer_satisfaction
                    FROM resolutions
                    """
                )
                connection.exec_driver_sql("DROP TABLE resolutions")
                connection.exec_driver_sql(
                    "ALTER TABLE resolutions_new RENAME TO resolutions"
                )

        connection.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_assignment_ticket_created "
            "ON assignment_events(ticket_id, created_at)"
        )
        connection.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_assignment_agent_created "
            "ON assignment_events(agent_id, created_at)"
        )
        connection.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_sla_ticket_created "
            "ON sla_events(ticket_id, created_at)"
        )
        connection.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_sla_type_created "
            "ON sla_events(event_type, created_at)"
        )
