"""
FastAPI application for Tixora Route.

Endpoints:
  GET  /health
  GET  /tickets               (paginated)
  GET  /tickets/{ticket_id}
  GET  /tickets/{ticket_id}/messages
  GET  /tickets/{ticket_id}/history
  GET  /agents                (paginated)
  GET  /queues
  POST /tickets/{ticket_id}/route
  GET  /metrics
  POST /validate

Swagger UI: /docs
ReDoc:      /redoc
"""
from fastapi import FastAPI, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, func

from .database import SessionLocal, init_db
from .models import Ticket, Agent, Queue, Message
from .schemas import (
    TicketCreate, TicketOut, TicketListOut,
    TicketDetailOut,
    MessageOut, AgentOut, AgentListOut, QueueOut,
    HistoryEntryOut, RouteResult, ValidationResult, HealthOut, MetricsOut,
)
from .routing import route_ticket
from .metrics import get_metrics
from .validation import validate
from . import __version__

app = FastAPI(
    title="Tixora Route",
    description=(
        "Intelligent Tixorachannel Ticket Routing and SLA Management Platform. "
        "YottaFlex.ai Associate AI Forward Deployed Engineer Round 2 Challenge."
    ),
    version=__version__,
    docs_url="/docs",
    redoc_url="/redoc",
)

# Initialise DB on startup (idempotent)
init_db()


def get_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── Health ───────────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthOut, tags=["Platform"])
def health():
    """Platform health check."""
    return {"status": "ok", "service": "tixora-route", "version": __version__}


# ── Tickets ───────────────────────────────────────────────────────────────────

@app.get("/tickets", response_model=TicketListOut, tags=["Tickets"])
def list_tickets(
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=1000),
    db: Session = Depends(get_session),
):
    """List tickets with pagination."""
    total = db.scalar(select(func.count(Ticket.id))) or 0
    items = list(db.scalars(select(Ticket).order_by(Ticket.id).offset(skip).limit(limit)))
    return TicketListOut(
        total=total,
        skip=skip,
        limit=limit,
        items=[TicketOut.model_validate(t) for t in items],
    )


@app.get("/tickets/{ticket_id}", response_model=TicketDetailOut, tags=["Tickets"])
def get_ticket(ticket_id: str, db: Session = Depends(get_session)):
    """Get a single ticket by public ID."""
    t = db.scalar(select(Ticket).where(Ticket.public_id == ticket_id))
    if not t:
        raise HTTPException(status_code=404, detail=f"Ticket {ticket_id!r} not found")
    return {
        "ticket": TicketOut.model_validate(t).model_dump(),
        "message_count": len(t.messages),
        "assignment_count": len(t.assignment_events),
    }


@app.get("/tickets/{ticket_id}/messages", response_model=list[MessageOut], tags=["Tickets"])
def get_ticket_messages(ticket_id: str, db: Session = Depends(get_session)):
    """Get all messages for a ticket (threaded)."""
    t = db.scalar(select(Ticket).where(Ticket.public_id == ticket_id))
    if not t:
        raise HTTPException(status_code=404, detail=f"Ticket {ticket_id!r} not found")
    return [MessageOut.model_validate(m) for m in sorted(t.messages, key=lambda m: m.created_at)]


@app.get("/tickets/{ticket_id}/history", response_model=list[HistoryEntryOut], tags=["Tickets"])
def get_ticket_history(ticket_id: str, db: Session = Depends(get_session)):
    """
    Get full lifecycle history for a ticket.

    Returns combined assignment events and SLA events, ordered by time.
    History is immutable — transfers, reopenings, and escalations are preserved.
    """
    t = db.scalar(select(Ticket).where(Ticket.public_id == ticket_id))
    if not t:
        raise HTTPException(status_code=404, detail=f"Ticket {ticket_id!r} not found")

    history = []
    for ev in t.assignment_events:
        history.append(HistoryEntryOut(
            event_type=ev.event_type,
            event_kind="assignment",
            public_id=ev.public_id,
            occurred_at=ev.created_at,
            detail=ev.reason,
        ))
    for ev in t.sla_events:
        history.append(HistoryEntryOut(
            event_type=ev.event_type,
            event_kind="sla",
            public_id=ev.public_id,
            occurred_at=ev.created_at,
            detail=ev.details,
        ))

    history.sort(key=lambda e: e.occurred_at)
    return history


# ── Agents ────────────────────────────────────────────────────────────────────

@app.get("/agents", response_model=AgentListOut, tags=["Agents"])
def list_agents(
    skip: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=1000),
    db: Session = Depends(get_session),
):
    """List agents with pagination."""
    total = db.scalar(select(func.count(Agent.id))) or 0
    items = list(db.scalars(select(Agent).order_by(Agent.id).offset(skip).limit(limit)))
    return AgentListOut(
        total=total,
        skip=skip,
        limit=limit,
        items=[AgentOut.model_validate(a) for a in items],
    )


# ── Queues ────────────────────────────────────────────────────────────────────

@app.get("/queues", response_model=list[QueueOut], tags=["Queues"])
def list_queues(db: Session = Depends(get_session)):
    """List all routing queues."""
    return [QueueOut.model_validate(q) for q in db.scalars(select(Queue))]


# ── Routing ───────────────────────────────────────────────────────────────────

@app.post("/tickets/{ticket_id}/route", response_model=RouteResult, tags=["Routing"])
def route(ticket_id: str, db: Session = Depends(get_session)):
    """
    Route a ticket to the best eligible agent.

    Enforces: skill match, language match, shift availability, capacity.
    Returns full explainability data including rejected candidates.
    """
    t = db.scalar(select(Ticket).where(Ticket.public_id == ticket_id))
    if not t:
        raise HTTPException(status_code=404, detail=f"Ticket {ticket_id!r} not found")
    if t.status not in {"new", "pending", "reopened"}:
        raise HTTPException(
            status_code=409,
            detail=f"Ticket {ticket_id!r} is already in state {t.status!r}",
        )
    try:
        result = route_ticket(db, t)
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    db.commit()
    return result


# ── Metrics ───────────────────────────────────────────────────────────────────

@app.get("/metrics", response_model=MetricsOut, tags=["Analytics"])
def metrics(db: Session = Depends(get_session)):
    """Platform metrics: tickets, messages, agents, routing, SLA, satisfaction."""
    return get_metrics(db)


# ── Validation ────────────────────────────────────────────────────────────────

@app.post("/validate", response_model=ValidationResult, tags=["Analytics"])
def run_validation(db: Session = Depends(get_session)):
    """
    Run full validation suite against the database.

    Returns validation status, issue count, and details.
    The clean baseline should always return valid=true with issue_count=0.
    """
    result = validate(db)
    return ValidationResult(
        valid=result["valid"],
        issue_count=result["issue_count"],
        issues=result["issues"],
        counts=result["counts"],
    )
