"""Isolated synthetic fixtures for the five documented anomaly scenarios."""

from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker

from .database import Base
from .generator import generate
from .models import Agent, AssignmentEvent, Intent, Ticket

SCENARIOS = {
    "agent_beyond_capacity",
    "incorrect_channel_sla_calendar",
    "lost_reopening_history",
    "transfer_loop",
    "priority_contradicts_safety_rule",
}


def build_anomaly_fixture(scenario: str, seed: int = 20261022):
    """Return a disposable ``(engine, session)`` containing one injected anomaly.

    Every call owns a fresh in-memory SQLite database. The regular clean-data
    generator never imports or injects these fixtures.
    """
    if scenario not in SCENARIOS:
        raise ValueError(f"Unknown anomaly scenario {scenario!r}; expected one of {sorted(SCENARIOS)}")

    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
    )
    Base.metadata.create_all(engine)
    session = sessionmaker(bind=engine, expire_on_commit=False)()

    try:
        generate(session, tickets=3, messages=3, seed=seed, agent_count=8)
        tickets = list(session.scalars(select(Ticket).order_by(Ticket.id)))
        agents = list(session.scalars(select(Agent).order_by(Agent.id)))
        ticket = tickets[0]

        if scenario == "agent_beyond_capacity":
            agent = agents[0]
            agent.capacity = 1
            for index, target in enumerate(tickets[:2], start=1):
                target.status = "open"
                session.add(AssignmentEvent(
                    public_id=f"ASN-{target.public_id}-001",
                    ticket=target,
                    agent=agent,
                    queue_name="fixture",
                    event_type="assigned",
                    reason="Isolated over-capacity anomaly fixture",
                    created_at=target.created_at,
                ))
        elif scenario == "incorrect_channel_sla_calendar":
            ticket.channel.calendar_type = (
                "24x7" if ticket.channel.calendar_type != "24x7" else "business"
            )
        elif scenario == "lost_reopening_history":
            ticket.status = "reopened"
            for event in list(ticket.sla_events):
                if event.event_type == "reopened":
                    session.delete(event)
        elif scenario == "transfer_loop":
            first, second = agents[:2]
            ticket.status = "open"
            for index, target_agent in enumerate((first, second, first), start=1):
                session.add(AssignmentEvent(
                    public_id=f"ASN-{ticket.public_id}-{index:03}",
                    ticket=ticket,
                    agent=target_agent,
                    source_agent=second if target_agent is first else first,
                    queue_name="fixture",
                    event_type="transferred",
                    reason="Isolated transfer-loop anomaly fixture",
                    created_at=ticket.created_at,
                ))
        else:
            safety = session.scalar(select(Intent).where(Intent.name == "safety"))
            ticket.intent = safety
            ticket.required_skill = "safety"
            ticket.priority = "normal"

        session.flush()
        return engine, session
    except Exception:
        session.close()
        engine.dispose()
        raise


def close_anomaly_fixture(engine, session) -> None:
    """Close and dispose the resources returned by ``build_anomaly_fixture``."""
    session.close()
    engine.dispose()
