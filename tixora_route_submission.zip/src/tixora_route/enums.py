"""Enumeration constants for Tixora Route."""

PRIORITY_RANK = {"low": 1, "normal": 2, "high": 3, "urgent": 4}

ALLOWED_STATUSES = {"new", "open", "pending", "escalated", "resolved", "reopened", "closed"}
ALLOWED_PRIORITIES = {"low", "normal", "high", "urgent"}
ALLOWED_SENDER_TYPES = {"customer", "agent", "system"}
ALLOWED_ASSIGNMENT_TYPES = {"assigned", "transferred", "escalated", "queued", "reopened"}
ALLOWED_SLA_TYPES = {"created", "breached", "resolved", "reopened", "escalated", "closed"}
ALLOWED_CALENDAR_TYPES = {"business", "calendar", "24x7"}

# Valid lifecycle transitions: from_state -> set of allowed to_states
VALID_TRANSITIONS = {
    "new": {"open", "pending", "resolved", "escalated", "closed"},
    "open": {"pending", "resolved", "escalated", "transferred", "closed"},
    "pending": {"open", "resolved", "escalated", "closed"},
    "escalated": {"open", "resolved", "closed"},
    "resolved": {"reopened", "closed"},
    "reopened": {"open", "pending", "resolved", "closed"},
    "closed": {"reopened"},
}
