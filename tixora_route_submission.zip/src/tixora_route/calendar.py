"""
Business calendar and SLA time calculation for Tixora Route.

Calendar types:
  - business : Mon–Fri, 09:00–17:00 local (UTC assumed for synthetic data)
  - calendar  : All days, 00:00–23:59 (24-hour but not 24x7 in naming)
  - 24x7      : Continuous wall-clock time

Timezone assumption: All synthetic timestamps are in UTC. The business
calendar operates on UTC hours (09:00–17:00 UTC = business window).
"""
from datetime import datetime, timedelta

BUSINESS_START = 9   # 09:00 UTC
BUSINESS_END = 17    # 17:00 UTC
WORKDAYS = (0, 1, 2, 3, 4)  # Mon=0 … Fri=4


def add_sla_minutes(
    start: datetime,
    minutes: int,
    calendar_type: str = "business",
    start_hour: int = BUSINESS_START,
    end_hour: int = BUSINESS_END,
    workdays: tuple = WORKDAYS,
) -> datetime:
    """
    Advance *start* by *minutes* of elapsed time according to *calendar_type*.

    - 24x7 / calendar: simple wall-clock addition.
    - business: skips non-working hours and weekend days.
    """
    if minutes < 0:
        raise ValueError("SLA minutes cannot be negative")
    if calendar_type not in {"business", "calendar", "24x7"}:
        raise ValueError(f"Unsupported SLA calendar type: {calendar_type!r}")
    if calendar_type in ("24x7", "calendar"):
        return start + timedelta(minutes=minutes)

    current = start
    remaining = minutes

    while remaining > 0:
        # Skip weekends
        if current.weekday() not in workdays:
            current = (current + timedelta(days=1)).replace(
                hour=start_hour, minute=0, second=0, microsecond=0
            )
            continue

        # Snap to start of business day if before opening
        if current.hour < start_hour:
            current = current.replace(hour=start_hour, minute=0, second=0, microsecond=0)

        # Skip if past end of business day
        if current.hour >= end_hour:
            current = (current + timedelta(days=1)).replace(
                hour=start_hour, minute=0, second=0, microsecond=0
            )
            continue

        # Minutes available until end of business day
        boundary = current.replace(hour=end_hour, minute=0, second=0, microsecond=0)
        available = int((boundary - current).total_seconds() // 60)
        step = min(remaining, available)
        current += timedelta(minutes=step)
        remaining -= step

        # Roll over to next business day if we hit the boundary
        if remaining > 0 and current.hour >= end_hour:
            current = (current + timedelta(days=1)).replace(
                hour=start_hour, minute=0, second=0, microsecond=0
            )

    return current


def elapsed_business_minutes(start: datetime, end: datetime, calendar_type: str = "business") -> float:
    """
    Calculate elapsed business minutes between two datetimes.

    Uses bisection approach: advance start in steps to approximate elapsed time.
    For 24x7/calendar, returns simple wall-clock minutes.
    """
    if calendar_type not in {"business", "calendar", "24x7"}:
        raise ValueError(f"Unsupported SLA calendar type: {calendar_type!r}")
    if calendar_type in ("24x7", "calendar"):
        return max(0.0, (end - start).total_seconds() / 60)

    if end <= start:
        return 0.0

    # Simple accumulation approach
    total = 0.0
    current = start

    while current < end:
        if current.weekday() not in WORKDAYS:
            current = (current + timedelta(days=1)).replace(
                hour=BUSINESS_START, minute=0, second=0, microsecond=0
            )
            continue

        if current.hour < BUSINESS_START:
            current = current.replace(hour=BUSINESS_START, minute=0, second=0, microsecond=0)

        if current.hour >= BUSINESS_END:
            current = (current + timedelta(days=1)).replace(
                hour=BUSINESS_START, minute=0, second=0, microsecond=0
            )
            continue

        boundary = current.replace(hour=BUSINESS_END, minute=0, second=0, microsecond=0)
        day_end = min(end, boundary)
        total += (day_end - current).total_seconds() / 60
        current = boundary

    return total
