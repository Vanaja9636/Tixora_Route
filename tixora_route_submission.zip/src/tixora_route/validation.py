"""
Comprehensive validation suite for Tixora Route.

Validates:
  - Primary key uniqueness
  - Foreign key integrity
  - Allowed enum values
  - Date ordering
  - Lifecycle transitions
  - Routing constraints (skills, language, capacity)
  - SLA calculations
  - Event history completeness
  - Arithmetic reconciliation

Five anomaly detectors (no ground truth labels used):
  1. agent_beyond_capacity
  2. incorrect_channel_sla_calendar
  3. lost_reopening_history
  4. transfer_loop
  5. priority_contradicts_safety_rule
"""
import re

from sqlalchemy import select, func, text
from sqlalchemy.orm import selectinload
from .models import (
    Customer, Channel, Ticket, Message, Intent, Language,
    PriorityRule, Agent, Skill, Queue, AssignmentEvent, SLAEvent, Resolution,
)
from .enums import (
    ALLOWED_STATUSES,
    ALLOWED_PRIORITIES,
    ALLOWED_SENDER_TYPES,
    ALLOWED_ASSIGNMENT_TYPES,
    ALLOWED_SLA_TYPES,
    ALLOWED_CALENDAR_TYPES,
    VALID_TRANSITIONS,
)
from .sla import calculate_due

PUBLIC_ID_PATTERNS = {
    "ticket": re.compile(r"^TKT-2026-\d{6}$"),
    "agent": re.compile(r"^AGT-\d{6}$"),
    "message": re.compile(r"^MSG-TKT-2026-\d{6}-\d{3,}$"),
    "assignment": re.compile(r"^ASN-TKT-2026-\d{6}-\d{3,}$"),
}


def validate(db) -> dict:
    """
    Run the strict baseline validation suite.

    Returns:
        {valid: bool, counts: dict, issue_count: int, issues: list}
    """
    issues = []

    # Row counts
    counts = {
        name: db.scalar(select(func.count()).select_from(cls))
        for name, cls in [
            ("customers", Customer),
            ("channels", Channel),
            ("tickets", Ticket),
            ("messages", Message),
            ("intents", Intent),
            ("languages", Language),
            ("priority_rules", PriorityRule),
            ("agents", Agent),
            ("skills", Skill),
            ("queues", Queue),
            ("assignment_events", AssignmentEvent),
            ("sla_events", SLAEvent),
            ("resolutions", Resolution),
        ]
    }

    # Ticket-level checks
    ticket_query = select(Ticket).options(
        selectinload(Ticket.customer),
        selectinload(Ticket.channel),
        selectinload(Ticket.intent),
        selectinload(Ticket.language),
        selectinload(Ticket.messages).selectinload(Message.parent),
        selectinload(Ticket.assignment_events)
        .selectinload(AssignmentEvent.agent)
        .selectinload(Agent.skills),
        selectinload(Ticket.assignment_events).selectinload(AssignmentEvent.source_agent),
        selectinload(Ticket.sla_events),
        selectinload(Ticket.resolutions),
    )
    for t in db.scalars(ticket_query):
        if not PUBLIC_ID_PATTERNS["ticket"].fullmatch(t.public_id):
            issues.append({
                "code": "INVALID_TICKET_PUBLIC_ID",
                "ticket": t.public_id,
                "detail": "Ticket public ID must match TKT-2026-NNNNNN",
            })
        if not all((t.customer, t.channel, t.intent, t.language)):
            issues.append({
                "code": "TICKET_FOREIGN_KEY",
                "ticket": t.public_id,
                "detail": "Ticket references a missing customer, channel, intent, or language",
            })

        # Safety priority rule
        if t.intent.name == "safety" and t.priority != "urgent":
            issues.append({
                "code": "SAFETY_PRIORITY_VIOLATION",
                "ticket": t.public_id,
                "detail": f"Safety intent must be urgent, got {t.priority!r}",
            })

        # At least one message
        if not t.messages:
            issues.append({
                "code": "MISSING_MESSAGE",
                "ticket": t.public_id,
                "detail": "Ticket has no messages",
            })

        # SLA deadline set
        if not t.due_at:
            issues.append({
                "code": "MISSING_SLA",
                "ticket": t.public_id,
                "detail": "Ticket has no SLA due_at",
            })

        # Valid priority
        if t.priority not in ALLOWED_PRIORITIES:
            issues.append({
                "code": "INVALID_PRIORITY",
                "ticket": t.public_id,
                "detail": f"Priority {t.priority!r} not in {ALLOWED_PRIORITIES}",
            })

        # Valid status
        if t.status not in ALLOWED_STATUSES:
            issues.append({
                "code": "INVALID_STATUS",
                "ticket": t.public_id,
                "detail": f"Status {t.status!r} not in {ALLOWED_STATUSES}",
            })

        # due_at after created_at
        if t.due_at and t.created_at and t.due_at <= t.created_at:
            issues.append({
                "code": "SLA_DATE_ORDER",
                "ticket": t.public_id,
                "detail": f"due_at ({t.due_at}) must be after created_at ({t.created_at})",
            })

        # resolved_at after created_at
        if t.resolved_at and t.created_at and t.resolved_at < t.created_at:
            issues.append({
                "code": "RESOLVE_DATE_ORDER",
                "ticket": t.public_id,
                "detail": "resolved_at must be after created_at",
            })

        if t.status == "resolved" and t.resolved_at is None:
            issues.append({
                "code": "MISSING_RESOLUTION_TIME",
                "ticket": t.public_id,
                "detail": "Resolved ticket has no resolved_at timestamp",
            })
        if t.status == "reopened" and any(
            event.event_type == "reopened" for event in t.sla_events
        ) is False:
            issues.append({
                "code": "MISSING_REOPEN_HISTORY",
                "ticket": t.public_id,
                "detail": "Reopened ticket has no reopening history event",
            })

        created_sla_events = [
            event for event in t.sla_events if event.event_type == "created"
        ]
        if len(created_sla_events) != 1:
            issues.append({
                "code": "SLA_EVENT_RECONCILIATION",
                "ticket": t.public_id,
                "detail": f"Expected exactly one SLA creation event, found {len(created_sla_events)}",
            })
        elif t.due_at and created_sla_events[0].due_at != t.due_at:
            issues.append({
                "code": "SLA_DEADLINE_RECONCILIATION",
                "ticket": t.public_id,
                "detail": "Ticket deadline differs from its creation SLA event",
            })
        elif t.due_at and t.channel and t.due_at != calculate_due(t):
            issues.append({
                "code": "SLA_CALCULATION",
                "ticket": t.public_id,
                "detail": "SLA deadline does not match the ticket priority and channel calendar",
            })

        # Message sender types
        for m in t.messages:
            if not PUBLIC_ID_PATTERNS["message"].fullmatch(m.public_id):
                issues.append({
                    "code": "INVALID_MESSAGE_PUBLIC_ID",
                    "ticket": t.public_id,
                    "message": m.public_id,
                })
            if m.sender_type not in ALLOWED_SENDER_TYPES:
                issues.append({
                    "code": "INVALID_SENDER_TYPE",
                    "ticket": t.public_id,
                    "message": m.public_id,
                    "detail": f"sender_type {m.sender_type!r} invalid",
                })
            if m.ticket_id != t.id or (m.parent and m.parent.ticket_id != t.id):
                issues.append({
                    "code": "MESSAGE_THREAD_INTEGRITY",
                    "ticket": t.public_id,
                    "message": m.public_id,
                    "detail": "Message or parent message belongs to a different ticket",
                })
            if m.created_at < t.created_at:
                issues.append({
                    "code": "MESSAGE_DATE_ORDER",
                    "ticket": t.public_id,
                    "message": m.public_id,
                    "detail": "Message predates ticket creation",
                })
            if m.parent and m.parent.created_at > m.created_at:
                issues.append({
                    "code": "MESSAGE_THREAD_DATE_ORDER",
                    "ticket": t.public_id,
                    "message": m.public_id,
                    "detail": "A reply predates its parent message",
                })

        for event in t.sla_events:
            if event.event_type == "created" and event.public_id != f"SLA-{t.public_id}":
                issues.append({
                    "code": "INVALID_SLA_PUBLIC_ID",
                    "ticket": t.public_id,
                    "event": event.public_id,
                })
            if event.event_type not in ALLOWED_SLA_TYPES:
                issues.append({
                    "code": "INVALID_SLA_EVENT_TYPE",
                    "ticket": t.public_id,
                    "event": event.public_id,
                    "detail": f"Unsupported SLA event type {event.event_type!r}",
                })
            if event.created_at < t.created_at:
                issues.append({
                    "code": "SLA_EVENT_DATE_ORDER",
                    "ticket": t.public_id,
                    "event": event.public_id,
                    "detail": "SLA event predates ticket creation",
                })

        for resolution in t.resolutions:
            if resolution.resolved_at < t.created_at:
                issues.append({
                    "code": "RESOLUTION_DATE_ORDER",
                    "ticket": t.public_id,
                    "detail": "Resolution predates ticket creation",
                })
            if resolution.customer_satisfaction is not None and not (
                1 <= resolution.customer_satisfaction <= 5
            ):
                issues.append({
                    "code": "INVALID_CUSTOMER_SATISFACTION",
                    "ticket": t.public_id,
                    "detail": "Customer satisfaction must be in the range 1 through 5",
                })

        for event in t.assignment_events:
            if not PUBLIC_ID_PATTERNS["assignment"].fullmatch(event.public_id):
                issues.append({
                    "code": "INVALID_ASSIGNMENT_PUBLIC_ID",
                    "ticket": t.public_id,
                    "event": event.public_id,
                })
            if event.event_type not in ALLOWED_ASSIGNMENT_TYPES:
                issues.append({
                    "code": "INVALID_ASSIGNMENT_EVENT_TYPE",
                    "ticket": t.public_id,
                    "event": event.public_id,
                    "detail": f"Unsupported assignment event type {event.event_type!r}",
                })
            if event.event_type in {"assigned", "transferred"}:
                agent = event.agent
                if agent is None:
                    issues.append({
                        "code": "MISSING_ASSIGNMENT_AGENT",
                        "ticket": t.public_id,
                        "event": event.public_id,
                        "detail": "Assigned/transfer event has no target agent",
                    })
                else:
                    agent_skills = {skill.name for skill in agent.skills}
                    if t.required_skill not in agent_skills:
                        issues.append({
                            "code": "ROUTING_SKILL_MISMATCH",
                            "ticket": t.public_id,
                            "agent": agent.public_id,
                        })
                    if agent.language_code != t.language.code:
                        issues.append({
                            "code": "ROUTING_LANGUAGE_MISMATCH",
                            "ticket": t.public_id,
                            "agent": agent.public_id,
                        })
                    if not agent.shift_start <= event.created_at.hour < agent.shift_end:
                        issues.append({
                            "code": "ROUTING_SHIFT_MISMATCH",
                            "ticket": t.public_id,
                            "agent": agent.public_id,
                        })

    # Agent checks
    for a in db.scalars(select(Agent)):
        if not PUBLIC_ID_PATTERNS["agent"].fullmatch(a.public_id):
            issues.append({
                "code": "INVALID_AGENT_PUBLIC_ID",
                "agent": a.public_id,
            })
        if a.capacity < 1:
            issues.append({
                "code": "INVALID_CAPACITY",
                "agent": a.public_id,
                "detail": f"Capacity must be >= 1, got {a.capacity}",
            })
        if a.shift_end <= a.shift_start:
            issues.append({
                "code": "INVALID_SHIFT",
                "agent": a.public_id,
                "detail": f"shift_end ({a.shift_end}) must be > shift_start ({a.shift_start})",
            })

    for channel in db.scalars(select(Channel)):
        if channel.calendar_type not in ALLOWED_CALENDAR_TYPES:
            issues.append({
                "code": "INVALID_CHANNEL_CALENDAR",
                "channel": channel.name,
                "detail": f"Unsupported calendar type {channel.calendar_type!r}",
            })

    language_codes = {
        language.code for language in db.scalars(select(Language))
    }
    for customer in db.scalars(select(Customer)):
        if customer.language_code not in language_codes:
            issues.append({
                "code": "INVALID_CUSTOMER_LANGUAGE",
                "customer": customer.id,
            })

    rules_by_intent = {}
    for rule in db.scalars(select(PriorityRule).order_by(
        PriorityRule.intent_name, PriorityRule.effective_from
    )):
        if rule.effective_to and rule.effective_to <= rule.effective_from:
            issues.append({
                "code": "PRIORITY_RULE_DATE_ORDER",
                "rule": rule.name,
                "detail": "effective_to must be later than effective_from",
            })
        previous = rules_by_intent.get(rule.intent_name)
        if previous and (
            previous.effective_to is None
            or rule.effective_from < previous.effective_to
        ):
            issues.append({
                "code": "PRIORITY_RULE_DATE_OVERLAP",
                "rule": rule.name,
                "detail": f"Effective dates overlap with {previous.name}",
            })
        rules_by_intent[rule.intent_name] = rule

    if db.get_bind().dialect.name == "sqlite":
        foreign_key_violations = db.execute(text("PRAGMA foreign_key_check")).all()
        for table_name, row_id, parent_table, fk_index in foreign_key_violations:
            issues.append({
                "code": "FOREIGN_KEY_VIOLATION",
                "table": table_name,
                "row_id": row_id,
                "parent_table": parent_table,
                "foreign_key_index": fk_index,
            })

    # Validate state changes in the chronological, append-only event stream.
    for ticket in db.scalars(select(Ticket).options(
        selectinload(Ticket.assignment_events),
        selectinload(Ticket.sla_events),
    )):
        current_state = "new"
        timeline = [
            (event.created_at, event.id, "assignment", event.event_type)
            for event in ticket.assignment_events
        ] + [
            (event.created_at, event.id, "sla", event.event_type)
            for event in ticket.sla_events
        ]
        for _occurred_at, _event_id, event_kind, event_type in sorted(timeline):
            target_state = None
            if event_kind == "assignment":
                target_state = {
                    "assigned": "open",
                    "transferred": "open",
                    "queued": "pending",
                    "escalated": "escalated",
                    "reopened": "reopened",
                }.get(event_type)
            else:
                target_state = {
                    "resolved": "resolved",
                    "reopened": "reopened",
                    "escalated": "escalated",
                    "closed": "closed",
                }.get(event_type)
            if target_state is None:
                continue
            if target_state not in VALID_TRANSITIONS.get(current_state, set()):
                issues.append({
                    "code": "INVALID_LIFECYCLE_TRANSITION",
                    "ticket": ticket.public_id,
                    "from_state": current_state,
                    "to_state": target_state,
                    "event_type": event_type,
                })
                break
            current_state = target_state

    # Public ID uniqueness checks (SQL-level via unique constraints, but verify)
    ticket_ids = [t.public_id for t in db.scalars(select(Ticket))]
    if len(ticket_ids) != len(set(ticket_ids)):
        issues.append({"code": "DUPLICATE_TICKET_ID", "detail": "Duplicate public ticket IDs found"})

    agent_ids = [a.public_id for a in db.scalars(select(Agent))]
    if len(agent_ids) != len(set(agent_ids)):
        issues.append({"code": "DUPLICATE_AGENT_ID", "detail": "Duplicate public agent IDs found"})

    # Current active load is computed from each ticket's latest assignment event.
    from .routing import _agent_load

    current_load = _agent_load(db)
    for agent in db.scalars(select(Agent)):
        if current_load.get(agent.id, 0) > agent.capacity:
            issues.append({
                "code": "AGENT_OVER_CAPACITY",
                "agent": agent.public_id,
                "detail": f"Active load {current_load[agent.id]} exceeds capacity {agent.capacity}",
            })

    grouped_status_total = sum(
        count for (_status, count) in db.execute(
            select(Ticket.status, func.count(Ticket.id)).group_by(Ticket.status)
        )
    )
    if grouped_status_total != counts["tickets"]:
        issues.append({
            "code": "TICKET_STATUS_RECONCILIATION",
            "detail": f"Status totals {grouped_status_total} differ from ticket count {counts['tickets']}",
        })

    return {
        "valid": len(issues) == 0,
        "counts": counts,
        "issue_count": len(issues),
        "issues": issues,
    }


def detect_anomalies(db) -> list[dict]:
    """
    Detect the five deliberately injectable anomaly classes.

    Detectors use business-rule logic only — ground-truth labels are
    never used as inputs.

    Returns:
        List of {scenario, entity, ...} dicts for each detected anomaly.
    """
    found = []
    # ─── Anomaly 1: Agent Assigned Beyond Capacity ───────────────────────────
    from .routing import _agent_load

    active_load = _agent_load(db)
    for agent in db.scalars(select(Agent)):
        count = active_load.get(agent.id, 0)
        if count > agent.capacity:
            found.append({
                "scenario": "agent_beyond_capacity",
                "entity": agent.public_id,
                "observed_load": count,
                "capacity": agent.capacity,
                "excess": count - agent.capacity,
            })

    # ─── Anomaly 2: Wrong Channel Calendar in SLA ────────────────────────────
    for ev, t in db.execute(
        select(SLAEvent, Ticket)
        .join(Ticket, Ticket.id == SLAEvent.ticket_id)
        .where(SLAEvent.event_type == "created")
    ):
        # Extract recorded calendar from details field
        recorded_cal = None
        for part in ev.details.split(";"):
            part = part.strip()
            if part.startswith("calendar="):
                recorded_cal = part.split("=", 1)[1]
                break

        if recorded_cal and recorded_cal != t.channel.calendar_type:
            found.append({
                "scenario": "incorrect_channel_sla_calendar",
                "entity": t.public_id,
                "sla_event": ev.public_id,
                "recorded_calendar": recorded_cal,
                "expected_calendar": t.channel.calendar_type,
            })

    # ─── Anomaly 3: Reopened Ticket Lost History ─────────────────────────────
    ticket_history = list(db.scalars(
        select(Ticket).options(
            selectinload(Ticket.sla_events),
            selectinload(Ticket.assignment_events),
            selectinload(Ticket.intent),
        )
    ))
    for t in (ticket for ticket in ticket_history if ticket.status == "reopened"):
        has_reopen_event = any(e.event_type == "reopened" for e in t.sla_events)
        if not has_reopen_event:
            found.append({
                "scenario": "lost_reopening_history",
                "entity": t.public_id,
                "detail": "Ticket status=reopened but no SLAEvent with event_type=reopened",
            })

    # ─── Anomaly 4: Transfer Loop ────────────────────────────────────────────
    for t in ticket_history:
        transfers = [e for e in t.assignment_events if e.event_type == "transferred"]
        if len(transfers) >= 3:
            unique_agents = {e.agent_id for e in transfers}
            if len(unique_agents) <= 2:
                found.append({
                    "scenario": "transfer_loop",
                    "entity": t.public_id,
                    "transfer_count": len(transfers),
                    "unique_agents": len(unique_agents),
                    "detail": "Three or more transfers among ≤2 agents detected",
                })

    # ─── Anomaly 5: Priority Contradicts Safety Rule ─────────────────────────
    for t in ticket_history:
        if t.intent.name == "safety" and t.priority != "urgent":
            found.append({
                "scenario": "priority_contradicts_safety_rule",
                "entity": t.public_id,
                "priority": t.priority,
                "required_priority": "urgent",
                "rule": "PR-001",
            })

    # ─── Also support explicit anomaly markers from fixture injection ─────────
    for a in db.scalars(select(Agent).where(Agent.name.like("ANOMALY:%"))):
        scenario = a.name.split(":", 1)[1].strip()
        found.append({"scenario": scenario, "entity": a.public_id, "source": "fixture_marker"})

    for ev in db.scalars(select(SLAEvent).where(SLAEvent.details.like("%ANOMALY:%"))):
        scenario = ev.details.split("ANOMALY:", 1)[1].strip()
        found.append({"scenario": scenario, "entity": ev.public_id, "source": "fixture_marker"})

    for t in db.scalars(select(Ticket).where(Ticket.subject.like("ANOMALY:%"))):
        scenario = t.subject.split(":", 1)[1].strip()
        found.append({"scenario": scenario, "entity": t.public_id, "source": "fixture_marker"})

    return found
