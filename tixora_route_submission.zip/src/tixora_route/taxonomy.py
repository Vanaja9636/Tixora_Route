"""Master taxonomy: intents, languages, channels for Tixora Route."""

# intent_name -> required_skill
INTENTS = {
    "billing": "billing",
    "technical": "technical",
    "account_access": "identity",
    "safety": "safety",
    "returns": "returns",
}

# language_code -> language_name
LANGUAGES = {
    "en": "English",
    "es": "Spanish",
    "hi": "Hindi",
    "te": "Telugu",
}

# channel_name -> calendar_type
CHANNELS = {
    "email": "business",
    "chat": "business",
    "phone": "business",
    "social": "calendar",
    "web": "business",
}

# Realistic message subjects per intent
SUBJECTS = {
    "billing": [
        "Invoice discrepancy on account",
        "Incorrect charge on my bill",
        "Request for billing statement",
        "Payment not reflected",
        "Refund request for duplicate payment",
    ],
    "technical": [
        "Application not responding",
        "Login page broken",
        "API error 500 on endpoint",
        "Feature stopped working after update",
        "Performance degradation noticed",
    ],
    "account_access": [
        "Cannot log into my account",
        "Account locked out",
        "Two-factor authentication issue",
        "Password reset not working",
        "Unauthorized access detected",
    ],
    "safety": [
        "URGENT: Safety hazard reported",
        "Critical safety incident",
        "Safety protocol violation",
        "Emergency safety concern",
        "Safety compliance issue",
    ],
    "returns": [
        "Product return request",
        "Item damaged on arrival",
        "Wrong item delivered",
        "Return label not received",
        "Refund status inquiry",
    ],
}

# Realistic message bodies
MESSAGE_BODIES = {
    "customer": [
        "I need help with this issue as soon as possible.",
        "This has been happening for several days now.",
        "Please expedite this request.",
        "Thank you for your assistance.",
        "Can you provide an update on this?",
        "I've already tried the suggested solutions.",
        "This is affecting my business operations.",
        "Please escalate if needed.",
    ],
    "agent": [
        "Thank you for contacting us. I'm looking into this now.",
        "I've reviewed your account and can see the issue.",
        "I've escalated this to our specialist team.",
        "This has been resolved. Please confirm.",
        "We're working on a fix and will update you shortly.",
        "Could you please provide more details?",
        "I've applied the correction to your account.",
        "Your request has been processed successfully.",
    ],
    "system": [
        "Ticket automatically escalated due to SLA breach.",
        "Ticket transferred to specialist queue.",
        "SLA deadline approaching.",
        "Auto-response: We received your request.",
    ],
}

# Priority weights for realistic distribution (low, normal, high, urgent)
PRIORITY_WEIGHTS = {
    "billing": [10, 55, 25, 10],
    "technical": [5, 45, 35, 15],
    "account_access": [5, 40, 35, 20],
    "safety": [0, 0, 0, 100],   # safety always urgent
    "returns": [15, 60, 20, 5],
}
