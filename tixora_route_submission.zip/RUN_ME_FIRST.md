# Tixora Route — run first (Windows)

Open PowerShell in `C:\Users\vanaj\Downloads\Tixora_Route`.

```powershell
cd C:\Users\vanaj\Downloads\Tixora_Route
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e .
python -m tixora_route.cli demo
python -m pytest -q tests
```

The demo writes the SQLite database to `data\cli_demo.db` and its checksummed CSV, JSON, and SQL outputs to `exports\`.

Start the API in a separate terminal:

```powershell
cd C:\Users\vanaj\Downloads\Tixora_Route
.\.venv\Scripts\Activate.ps1
python -m uvicorn tixora_route.api:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000/docs`. Health check: `http://127.0.0.1:8000/health`.

For exact routes, full-scale generation, validation, metrics, export formats, and troubleshooting, see [`README.md`](README.md).
